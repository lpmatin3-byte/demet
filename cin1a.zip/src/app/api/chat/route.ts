import { db } from "@/db";
import { chatMessages } from "@/db/schema";
import { answerQuestion } from "@/lib/chat/engine";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as { message?: string; sessionId?: string };
    const message = (body.message ?? "").toString().slice(0, 1200);
    const sessionId = (body.sessionId ?? "anonymous").toString().slice(0, 64);

    const result = await answerQuestion(message);

    try {
      await ensureSeeded();
      await db.insert(chatMessages).values([
        { sessionId, role: "user", content: message || "(خالی)", intent: result.intent },
        { sessionId, role: "assistant", content: result.reply.slice(0, 4000), intent: result.intent },
      ]);
    } catch {
      // ثبت گفتگو نباید پاسخ را متوقف کند
    }

    return Response.json({ ok: true, ...result });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}
