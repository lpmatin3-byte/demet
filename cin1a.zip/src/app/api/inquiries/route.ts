import { db } from "@/db";
import { inquiries } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      name?: string;
      phone?: string;
      message?: string;
      propertyCode?: string;
    };
    const name = (body.name ?? "").toString().trim();
    const phone = (body.phone ?? "").toString().trim();

    if (name.length < 2 || phone.length < 8) {
      return Response.json({ ok: false, error: "نام و شمارهٔ تماس معتبر وارد کنید." }, { status: 400 });
    }

    await ensureSeeded();
    await db.insert(inquiries).values({
      name: name.slice(0, 120),
      phone: phone.slice(0, 30),
      message: (body.message ?? "").toString().slice(0, 2000) || null,
      propertyCode: (body.propertyCode ?? "").toString().slice(0, 30) || null,
    });

    return Response.json({ ok: true });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message }, { status: 500 });
  }
}
