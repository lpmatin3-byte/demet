import { getNeighborhoods } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const items = await getNeighborhoods();
    return Response.json({ ok: true, count: items.length, items });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message, items: [] }, { status: 500 });
  }
}
