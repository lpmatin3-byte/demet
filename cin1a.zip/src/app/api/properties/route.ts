import { getProperties } from "@/lib/queries";

export const dynamic = "force-dynamic";

function num(value: string | null): number | undefined {
  if (!value) return undefined;
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : undefined;
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  try {
    const items = await getProperties({
      deal: searchParams.get("deal") ?? undefined,
      category: searchParams.get("category") ?? undefined,
      type: searchParams.get("type") ?? undefined,
      neighborhood: searchParams.get("neighborhood") ?? undefined,
      minArea: num(searchParams.get("minArea")),
      maxArea: num(searchParams.get("maxArea")),
      rooms: num(searchParams.get("rooms")),
      q: searchParams.get("q") ?? undefined,
      sort: searchParams.get("sort") ?? undefined,
      limit: num(searchParams.get("limit")),
      featured: searchParams.get("featured") === "1" ? true : undefined,
    });
    return Response.json({ ok: true, count: items.length, items });
  } catch (error) {
    return Response.json({ ok: false, error: (error as Error).message, items: [] }, { status: 500 });
  }
}
