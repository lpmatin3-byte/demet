import Link from "next/link";
import { notFound } from "next/navigation";
import InquiryForm from "@/components/InquiryForm";
import Parallax from "@/components/Parallax";
import Reveal from "@/components/Reveal";
import SmartImage from "@/components/SmartImage";
import { REAL_SOURCES } from "@/lib/data/real-media";
import { formatPerM2, formatPriceShort, formatShortToman, toFa } from "@/lib/format";
import { getBuildingBySlug, getBuildings, getNeighborhood } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function BuildingPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const building = await getBuildingBySlug(slug);
  if (!building) notFound();

  const nb = await getNeighborhood(building.neighborhoodSlug);
  const others = (await getBuildings()).filter((b) => b.slug !== slug).slice(0, 4);

  const specs = [
    { k: "سازنده", v: building.builder },
    { k: "معمار", v: building.architect },
    { k: "سبک", v: building.style },
    { k: "سال ساخت", v: toFa(building.yearBuilt) },
    { k: "طبقات", v: building.floors },
    { k: "تعداد واحد", v: building.units },
    { k: "متراژ واحدها", v: building.unitSizes },
    { k: "مساحت زمین", v: `${toFa(building.landArea)} متر مربع` },
    { k: "زیربنا", v: `${toFa(building.buildArea)} متر مربع` },
    { k: "هر متر", v: formatPerM2(building.salePerM2) },
    { k: "شروع قیمت", v: formatPriceShort(building.priceFrom) },
    { k: "کاربری", v: building.usage === "residential" ? "مسکونی" : building.usage === "office" ? "اداری" : "تجاری" },
  ];

  return (
    <>
      <Parallax src={building.images[0]} height="min-h-[44vh]" speed={0.12} tint="from-ink via-ink/70 to-ink/95">
        <div className="mx-auto w-full max-w-7xl px-5 pt-24">
          <Link href="/#branded" className="text-xs text-amber hover:underline">
            ← پروژه‌های برند
          </Link>
          <p className="kicker mt-4">{building.nameEn} • {nb?.name}</p>
          <h1 className="display mt-3 text-[clamp(1.8rem,4.4vw,3.2rem)] text-cream">{building.name}</h1>
          <p className="mt-3 text-sm text-mist">{building.address}</p>
        </div>
      </Parallax>

      <section className="mx-auto max-w-7xl px-5 py-14">
        <div className="grid gap-10 lg:grid-cols-[1.6fr_1fr]">
          <div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {specs.map((s) => (
                <div key={s.k} className="rounded-[20px] border border-white/10 bg-charcoal/70 p-4">
                  <p className="text-[0.62rem] text-mist">{s.k}</p>
                  <p className="mt-1.5 text-[0.78rem] font-bold leading-6 text-cream">{s.v}</p>
                </div>
              ))}
            </div>

            <Reveal className="mt-10">
              <h2 className="text-xl font-extrabold text-cream">دربارهٔ پروژه</h2>
              <p className="mt-4 text-sm leading-8 text-mist">{building.description}</p>
            </Reveal>

            <Reveal className="mt-10">
              <h2 className="text-xl font-extrabold text-cream">تصاویر</h2>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                {building.images.map((img, i) => (
                  <SmartImage
                    key={img + i}
                    src={img}
                    fallback="/images/hero-villa.jpg"
                    alt={`${building.name} ${i + 1}`}
                    loading="lazy"
                    className="h-40 w-full rounded-2xl object-cover transition-transform duration-700 hover:scale-[1.05]"
                  />
                ))}
              </div>
            </Reveal>

            <div className="mt-10 grid gap-8 sm:grid-cols-2">
              <div>
                <h2 className="text-lg font-extrabold text-cream">امکانات</h2>
                <ul className="mt-4 space-y-2">
                  {building.features.map((f) => (
                    <li key={f} className="flex gap-2 text-[0.78rem] leading-6 text-mist">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-flame" />
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h2 className="text-lg font-extrabold text-cream">دسترسی‌های اطراف</h2>
                <ul className="mt-4 space-y-2">
                  {building.nearby.map((f) => (
                    <li key={f} className="flex gap-2 text-[0.78rem] leading-6 text-mist">
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold" />
                      {f}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <aside className="space-y-6">
            <div className="glass sticky top-24 rounded-[28px] p-6">
              <p className="kicker">قیمت — مهر ۱۴۰۵</p>
              <p className="display mt-4 text-3xl text-cream">{formatPerM2(building.salePerM2)}</p>
              <p className="mt-2 text-sm text-mist">شروع قیمت واحد: {formatPriceShort(building.priceFrom)}</p>
              {building.rentPerM2 > 0 ? (
                <div className="mt-5 space-y-2 border-t border-white/10 pt-5 text-[0.76rem] text-mist">
                  <p className="flex justify-between"><span>رهن کامل هر متر</span><b className="text-cream">{formatPriceShort(building.rentDepositPerM2)}</b></p>
                  <p className="flex justify-between"><span>اجارهٔ ماهانهٔ هر متر</span><b className="text-cream">{formatShortToman(building.rentPerM2)}</b></p>
                  <p className="flex justify-between"><span>نمونهٔ ۲۰۰ متری — رهن</span><b className="text-amber">{formatPriceShort(building.rentDepositPerM2 * 200)}</b></p>
                </div>
              ) : (
                <p className="mt-5 border-t border-white/10 pt-5 text-[0.76rem] text-mist">پروژه در مرحلهٔ پیش‌فروش است؛ رهن و اجاره ندارد.</p>
              )}
              {REAL_SOURCES[building.slug] && (
                <a
                  href={REAL_SOURCES[building.slug].url}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-5 block rounded-2xl border border-gold/30 bg-gold/10 p-4 text-[0.7rem] leading-6 text-gold"
                >
                  📷 {REAL_SOURCES[building.slug].label} — مشاهدهٔ منبع ↗
                </a>
              )}
              {nb && (
                <p className="mt-4 border-t border-white/10 pt-4 text-[0.72rem] leading-6 text-mist">
                  میانگین محلهٔ {nb.name}: {formatPerM2(nb.salePerM2)} در متر — این پروژه با ضریب{" "}
                  <b className="text-amber">{(building.salePerM2 / nb.salePerM2).toFixed(2)}×</b> نسبت به میانگین محله قیمت‌گذاری شده است.
                </p>
              )}
            </div>
            <InquiryForm propertyCode={building.nameEn} />
          </aside>
        </div>

        <div className="mt-20">
          <h2 className="display text-2xl text-cream">پروژه‌های برند دیگر</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {others.map((b) => (
              <Link
                key={b.slug}
                href={`/buildings/${b.slug}`}
                className="group relative block h-44 overflow-hidden rounded-[24px] border border-white/10"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={b.images[0]} alt={b.name} loading="lazy" className="h-full w-full object-cover opacity-70 transition-all duration-700 group-hover:scale-110 group-hover:opacity-100" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent" />
                <div className="absolute inset-x-4 bottom-4">
                  <h3 className="text-sm font-extrabold text-cream">{b.name}</h3>
                  <p className="text-[0.66rem] text-gold">{formatPerM2(b.salePerM2)}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
