import type { Metadata } from "next";
import type { ReactNode } from "react";
import { SiteFooter, SiteHeader } from "@/components/SiteChrome";
import ChatWidget from "@/components/ChatWidget";
import "./globals.css";

export const metadata: Metadata = {
  title: "Demet Home | املاک لوکس منطقه ۲ و ۳ تهران",
  description:
    "دیمت هوم — خرید، فروش و رهن و اجارهٔ املاک لوکس در ونک، جردن، میرداماد، ظفر، سعادت‌آباد، شهرک غرب و شیخ بهایی. تحلیل هوشمند قیمت و مشاور تخصصی.",
  keywords: [
    "املاک تهران",
    "خرید آپارتمان جردن",
    "رهن اجاره سعادت آباد",
    "شهرک غرب",
    "میرداماد",
    "ونک",
    "ظفر",
    "شیخ بهایی",
    "Demet Home",
  ],
  openGraph: {
    title: "Demet Home | املاک لوکس شمال تهران",
    description: "پلتفرم سینمایی املاک منطقهٔ ۲ و ۳ تهران با تحلیل هوشمند قیمت.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100..900&display=swap"
          rel="stylesheet"
        />
        <meta name="theme-color" content="#08080a" />
      </head>
      <body className="bg-ink text-cream antialiased">
        <SiteHeader />
        <main>{children}</main>
        <SiteFooter />
        <ChatWidget />
      </body>
    </html>
  );
}
