import Link from "next/link";
import Logo from "@/components/Logo";

export default function NotFound() {
  return (
    <section className="relative grid min-h-[100svh] place-items-center overflow-hidden px-5">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-30"
        style={{ backgroundImage: "url(/images/hero-villa.jpg)" }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-ink via-ink/85 to-ink" />
      <div className="relative text-center">
        <Logo className="justify-center" />
        <h1 className="display mt-8 text-[clamp(3rem,12vw,7rem)] gold-text">۴۰۴</h1>
        <p className="mt-4 text-lg font-bold text-cream">این آگهی در آرشیو Demet Home نیست</p>
        <p className="mx-auto mt-3 max-w-md text-sm leading-8 text-mist">
          شاید ملک فروخته یا اجاره داده شده باشد. آگهی‌های فعال منطقهٔ ۲ و ۳ تهران را ببینید یا از مشاور هوشمند بپرسید.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link
            href="/properties"
            className="rounded-full bg-gradient-to-l from-gold via-flame to-copper px-7 py-3.5 text-sm font-extrabold text-ink"
          >
            مشاهدهٔ آگهی‌ها
          </Link>
          <Link
            href="/"
            className="rounded-full border border-white/15 px-7 py-3.5 text-sm font-bold text-cream hover:border-flame/50"
          >
            صفحهٔ اصلی
          </Link>
        </div>
      </div>
    </section>
  );
}
