import Link from "next/link";
import CinematicHero from "@/components/CinematicHero";
import InquiryForm from "@/components/InquiryForm";
import Parallax from "@/components/Parallax";
import PropertyCard from "@/components/PropertyCard";
import Reveal from "@/components/Reveal";
import BuildingsShowcase from "@/components/BuildingsShowcase";
import TehranMap3D from "@/components/TehranMap3D";
import { ChatLauncherButton } from "@/components/ChatWidget";
import { IMG } from "@/lib/data/images";
import { formatPerM2, toFa } from "@/lib/format";
import { getBuildings, getMarketSnapshot, getNeighborhoods, getProperties } from "@/lib/queries";

export const dynamic = "force-dynamic";

function dealCards(avgPerM2: number, rentCount: number) {
  return [
  {
    href: "/properties?deal=sale",
    title: "فروش",
    sub: "مالکیتِ مطلق، از کلنگی تا پنت‌هاوس",
    img: IMG.villaTwilight,
    stat: `میانگین ${toFa(Math.round(avgPerM2 / 1000000))} میلیون تومان / متر`,
  },
  {
    href: "/properties?deal=rent",
    title: "رهن و اجاره",
    sub: "از رهن کامل تا کم‌رهنِ سکونت فوری",
    img: IMG.livingMinimal,
    stat: `${toFa(rentCount)} آگهی فعال اجاره‌ای`,
  },
  ];
}

const CATEGORY_CARDS = [
  { href: "/properties?category=residential", title: "مسکونی", icon: "🏙️", img: IMG.livingOpen, note: "سکونتِ آرام" },
  { href: "/properties?category=office", title: "اداری", icon: "🏛️", img: IMG.officeLobby, note: "دفتر و شرکت" },
  { href: "/properties?category=commercial", title: "تجاری", icon: "🛍️", img: IMG.shopJewel, note: "مغازه و مستغلات" },
];

const TYPE_CARDS = [
  { href: "/properties?type=apartment", title: "آپارتمان", img: IMG.facadeModern, note: "برج‌های نوساز" },
  { href: "/properties?type=villa", title: "ویلایی", img: IMG.villaStone, note: "حیاط اختصاصی" },
  { href: "/properties?type=mixed", title: "مستغلات", img: IMG.livingChandelier, note: "سرمایه‌گذاری" },
  { href: "/properties?type=old", title: "کلنگی", img: IMG.facadeClassic, note: "مشارکت در ساخت" },
  { href: "/properties?type=shop", title: "مغازه", img: IMG.shopFashion, note: "حق کسب و پیشه" },
];

const STORY = [
  {
    img: "/images/hero-penthouse.jpg",
    kicker: "Act I — Penthouse",
    title: "پنت‌هاوس‌های الهیه و ظفر",
    text: "طبقهٔ آخر، تراس اختصاصی و نمای باز به شهر. واحدهایی که هر سال فقط چند مورد از آن‌ها به بازار می‌آید.",
    href: "/properties?neighborhood=elahieh&type=apartment",
    cta: "دیدن پنت‌هاوس‌ها",
  },
  {
    img: IMG.villaPool,
    kicker: "Act II — Signature Villa",
    title: "ویلاهای دوبلکس سعادت‌آباد و دروس",
    text: "حیاط اختصاصی، استخر، پارکینگ چندگانه و معماری مینیمال؛ سبک زندگیِ کم‌یاب در تهران.",
    href: "/properties?type=villa",
    cta: "کالکشن ویلاها",
  },
  {
    img: IMG.officeLobby,
    kicker: "Act III — Office",
    title: "واحدهای اداری جردن و میرداماد",
    text: "لابی شیشه‌ای، پارکینگ VIP و دسترسی به بزرگراه‌ها؛ بهترین انتخاب برای دفتر شرکت شما.",
    href: "/properties?category=office",
    cta: "دفتر کار مناسب",
  },
];

const AI_PROMPTS = [
  "من یک خونهٔ دو خوابه ۱۰۰ متری می‌خوام تو کامکارها. رهن و اجاره‌ش چقدر می‌شه؟",
  "قیمت خرید آپارتمان ۱۲۰ متری در شمال جردن چقدره؟",
  "بهترین محله برای سرمایه‌گذاری اجاره‌ای کجاست؟",
  "قوانین تخلیهٔ ملک استیجاری رو توضیح بده",
];

export default async function HomePage() {
  const [nbs, featured, snapshot, branded] = await Promise.all([
    getNeighborhoods(),
    getProperties({ featured: true, limit: 10 }),
    getMarketSnapshot(),
    getBuildings(),
  ]);

  const maxPerM2 = Math.max(...nbs.map((n) => n.salePerM2));

  return (
    <>
      <CinematicHero
        stats={{ total: snapshot.total, sale: snapshot.sale, rent: snapshot.rent, neighborhoods: snapshot.neighborhoods }}
      />

      {/* marquee */}
      <div className="relative border-y border-white/10 bg-charcoal/80 py-4">
        <div className="marquee-track gap-10">
          {[...nbs, ...nbs].map((n, i) => (
            <span key={`${n.slug}-${i}`} className="flex items-center gap-3 whitespace-nowrap text-sm text-mist">
              <span className="text-flame">◆</span>
              <span className="font-bold text-cream">{n.name}</span>
              <span>{formatPerM2(n.salePerM2)}</span>
              <span className="text-amber">+{toFa(n.trendPct)}٪</span>
            </span>
          ))}
        </div>
      </div>

      {/* categories */}
      <section className="mx-auto max-w-7xl px-5 py-24">
        <Reveal>
          <p className="kicker">Categories</p>
          <h2 className="display mt-4 max-w-2xl text-[clamp(1.9rem,4.4vw,3.4rem)] text-cream">
            دسته‌بندی دقیق، <span className="gold-text">انتخابِ ساده</span>
          </h2>
          <p className="mt-4 max-w-xl text-sm leading-8 text-mist">
            سه سطح فیلتر: نوع معامله، کاربری ملک و فرم ساختمانی. بدون شلوغی، در دو کلیک به خواسته‌تان برسید.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {dealCards(snapshot.avgPerM2, snapshot.rent).map((c, i) => (
            <Reveal key={c.href} delay={i * 120}>
              <Link href={c.href} className="group relative block h-[300px] overflow-hidden rounded-[30px] border border-white/10">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={c.img}
                  alt={c.title}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-[1400ms] group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/45 to-transparent" />
                <div className="absolute inset-x-6 bottom-6">
                  <h3 className="display text-4xl text-cream">{c.title}</h3>
                  <p className="mt-2 text-sm text-cream/70">{c.sub}</p>
                  <p className="mt-4 inline-flex items-center gap-2 rounded-full bg-flame/90 px-4 py-2 text-[0.7rem] font-bold text-ink">
                    {c.stat}
                  </p>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        <div className="mt-5 grid gap-5 sm:grid-cols-3">
          {CATEGORY_CARDS.map((c, i) => (
            <Reveal key={c.href} delay={i * 100}>
              <Link
                href={c.href}
                className="group relative flex h-[190px] items-end overflow-hidden rounded-[26px] border border-white/10"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={c.img} alt={c.title} className="absolute inset-0 h-full w-full object-cover opacity-60 transition-all duration-1000 group-hover:scale-110 group-hover:opacity-90" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink to-transparent" />
                <div className="relative p-5">
                  <span className="text-2xl">{c.icon}</span>
                  <h3 className="mt-1 text-xl font-extrabold text-cream">{c.title}</h3>
                  <p className="text-xs text-mist">{c.note}</p>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>

        <div className="no-scrollbar mt-5 flex gap-4 overflow-x-auto pb-2">
          {TYPE_CARDS.map((c, i) => (
            <Reveal key={c.href} delay={i * 70} className="min-w-[190px] flex-1">
              <Link
                href={c.href}
                className="group relative block h-[150px] overflow-hidden rounded-[22px] border border-white/10 bg-ash"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={c.img} alt={c.title} className="absolute inset-0 h-full w-full object-cover opacity-45 transition-all duration-700 group-hover:scale-110 group-hover:opacity-80" />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/95 to-transparent" />
                <div className="relative flex h-full flex-col justify-end p-4">
                  <h4 className="text-base font-extrabold text-cream">{c.title}</h4>
                  <p className="text-[0.68rem] text-amber">{c.note}</p>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* featured */}
      <section className="relative border-y border-white/10 bg-charcoal/70 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="kicker">Featured Collection</p>
              <h2 className="display mt-4 text-[clamp(1.9rem,4.4vw,3.4rem)] text-cream">آگهی‌های شاخص</h2>
              <p className="mt-4 max-w-xl text-sm leading-8 text-mist">
                منتخبِ تیم بازاریابی Demet Home؛ بالاترین کیفیت ساخت، بهترین نما و نقدشونده‌ترین موقعیت.
              </p>
            </div>
            <Link
              href="/properties"
              className="rounded-full border border-flame/40 bg-flame/10 px-6 py-3 text-sm font-bold text-amber transition-colors hover:bg-flame hover:text-ink"
            >
              همهٔ آگهی‌ها ↗
            </Link>
          </Reveal>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featured.slice(0, 6).map((p, i) => (
              <Reveal key={p.id} delay={(i % 3) * 110} variant="blur">
                <PropertyCard item={p} priority={i < 3} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* branded towers */}
      <section id="branded" className="section-light border-t border-[#14161b]/10 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal>
            <p className="kicker">Signature Projects</p>
            <h2 className="display mt-4 max-w-3xl text-[clamp(1.9rem,4.4vw,3.4rem)]">
              برج‌ها و پروژه‌های <span className="gold-text">برند</span> منطقهٔ ۲ و ۳
            </h2>
            <p className="mt-4 max-w-2xl text-sm leading-8">
              از برج پارس جردن و برج هلیوس صرافها تا فیوچر و ساید پارک؛ مشخصات کامل، سازنده، معمار، متراژ واحدها،
              قیمت هر متر و رهن و اجارهٔ هر پروژه — به‌روزرسانی مهر ۱۴۰۵. روی هر پروژه بزنید تا جزئیات کامل را ببینید.
            </p>
          </Reveal>
          <div className="mt-10">
            <BuildingsShowcase items={branded} />
          </div>
        </div>
      </section>

      {/* 3D map */}
      <section id="map" className="section-light py-24">
        <div className="mx-auto max-w-7xl px-5">
        <Reveal>
          <p className="kicker">Interactive 3D Map</p>
          <h2 className="display mt-4 max-w-3xl text-[clamp(1.9rem,4.4vw,3.4rem)]">
            نقشهٔ <span className="gold-text">سه‌بعدی و متحرک</span> شمال تهران
          </h2>
          <p className="mt-4 max-w-2xl text-sm leading-8 text-mist">
            ارتفاع هر ستون، میانگین قیمت هر متر مربع در همان محله است. نقشه را بچرخانید، روی محله بزنید و قیمت لحظه‌ای
            فروش، رهن و اجاره را ببینید.
          </p>
        </Reveal>
        </div>
        <div className="mx-auto mt-12 max-w-7xl px-5">
          <TehranMap3D
            items={nbs.map((n) => ({
              slug: n.slug,
              name: n.name,
              district: n.district,
              lat: n.lat,
              lng: n.lng,
              salePerM2: n.salePerM2,
              rentPerM2: n.rentPerM2,
              depositPerM2: n.depositPerM2,
              trendPct: n.trendPct,
              yieldPct: n.yieldPct,
              tags: n.tags,
              tagline: n.tagline,
            }))}
          />
        </div>
      </section>

      {/* cinematic story */}
      {STORY.map((s) => (
        <Parallax key={s.title} src={s.img} height="min-h-[85vh]" speed={0.22}>
          <div className="mx-auto w-full max-w-7xl px-5">
            <Reveal className="max-w-xl">
              <p className="kicker">{s.kicker}</p>
              <h2 className="display mt-5 text-[clamp(1.8rem,4vw,3.2rem)] text-cream">{s.title}</h2>
              <p className="mt-5 text-sm leading-8 text-cream/70">{s.text}</p>
              <Link
                href={s.href}
                className="mt-8 inline-flex rounded-full bg-gradient-to-l from-gold via-flame to-copper px-7 py-3.5 text-sm font-extrabold text-ink"
              >
                {s.cta} ✦
              </Link>
            </Reveal>
          </div>
        </Parallax>
      ))}

      {/* insights */}
      <section id="insights" className="section-light border-t border-[#14161b]/10 py-24">
        <div className="mx-auto max-w-7xl px-5">
        <Reveal>
          <p className="kicker">Market Insights</p>
          <h2 className="display mt-4 text-[clamp(1.9rem,4.4vw,3.4rem)]">تحلیل قیمت محله‌ها</h2>
          <p className="mt-4 max-w-2xl text-sm leading-8">
            بر پایهٔ آگهی‌های فعال، معاملات ثبت‌شده و روند فصلی. اعداد حدودی و برای تصمیم‌گیری سریع است.
          </p>
        </Reveal>
        </div>

        <div className="mx-auto mt-12 max-w-7xl overflow-hidden rounded-[28px] border border-[#14161b]/12 bg-white/55 px-0 backdrop-blur-sm">
          <div className="grid grid-cols-[1.4fr_1fr_1fr_1fr] gap-2 border-b border-[#14161b]/10 bg-[#14161b]/5 px-5 py-4 text-[0.68rem] font-bold text-[#4a515c]">
            <span>محله</span>
            <span className="text-center">فروش هر متر</span>
            <span className="text-center">اجارهٔ ماهانهٔ هر متر</span>
            <span className="text-center">روند سالانه</span>
          </div>
          {nbs.map((n, i) => (
            <Reveal key={n.slug} delay={i * 45}>
              <Link
                href={`/properties?neighborhood=${n.slug}`}
                className="group grid grid-cols-[1.4fr_1fr_1fr_1fr] items-center gap-2 border-b border-[#14161b]/8 px-5 py-4 transition-colors last:border-0 hover:bg-copper/10"
              >
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold text-[#14161b] group-hover:text-copper">{n.name}</span>
                  <span className="hidden rounded-full bg-[#14161b]/8 px-2 py-0.5 text-[0.6rem] text-[#4a515c] sm:inline">
                    منطقه {toFa(n.district)}
                  </span>
                </div>
                <div className="text-center">
                  <span className="block text-sm font-bold text-cream">{formatPerM2(n.salePerM2)}</span>
                  <span className="mt-1.5 block h-1 overflow-hidden rounded-full bg-[#14161b]/12">
                    <span
                      className="block h-full rounded-full bg-gradient-to-l from-gold to-flame"
                      style={{ width: `${(n.salePerM2 / maxPerM2) * 100}%` }}
                    />
                  </span>
                </div>
                <span className="text-center text-sm text-[#14161b]/80">
                  {toFa(Math.round(n.rentPerM2 / 1000))} هزار تومان
                </span>
                <span className="text-center text-sm font-bold text-copper">+{toFa(n.trendPct)}٪</span>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* AI */}
      <section id="ai" className="relative overflow-hidden border-y border-white/10 py-24">
        <div
          className="absolute inset-0 opacity-25"
          style={{ backgroundImage: `url(${IMG.tehranAerial})`, backgroundSize: "cover", backgroundPosition: "center" }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-ink via-ink/85 to-ink" />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-2">
          <Reveal>
            <p className="kicker">Demet AI</p>
            <h2 className="display mt-4 text-[clamp(1.9rem,4.4vw,3.4rem)] text-cream">
              مشاورِ هوشمندی که <span className="gold-text">قیمت را می‌داند</span>
            </h2>
            <p className="mt-5 max-w-lg text-sm leading-8 text-mist">
              متراژ، تعداد خواب و محله را بگویید؛ دیمت‌آی‌آی بر پایهٔ داده‌های لحظه‌ای منطقهٔ ۲ و ۳ تهران و بررسی آگهی‌های
              دیوار، رهن، اجاره و قیمت فروش را همان لحظه برآورد می‌کند. سؤالات حقوقی ملکی را هم می‌پرسید.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ChatLauncherButton />
              <Link
                href="/properties"
                className="rounded-full border border-white/15 px-6 py-3.5 text-sm font-bold text-cream transition-colors hover:border-flame/50"
              >
                مرور آگهی‌ها
              </Link>
            </div>
          </Reveal>

          <div className="space-y-3">
            {AI_PROMPTS.map((p, i) => (
              <Reveal key={p} delay={i * 90}>
                <div className="glass flex items-start gap-4 rounded-[22px] p-5">
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-flame/15 text-sm text-amber">
                    ✦
                  </span>
                  <p className="text-sm leading-7 text-cream/85">{p}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* contact */}
      <section className="mx-auto grid max-w-7xl gap-12 px-5 py-24 lg:grid-cols-2">
        <Reveal>
          <p className="kicker">Contact</p>
          <h2 className="display mt-4 text-[clamp(1.9rem,4.4vw,3.4rem)] text-cream">بیایید شروع کنیم</h2>
          <p className="mt-5 max-w-lg text-sm leading-8 text-mist">
            تیم Demet Home در بلوار نلسون ماندلا مستقر است. چه بخواهید بفروشید، چه بخواهید بخواهید؛ ما بازار شمال تهران را
            خانه‌به‌خانه می‌شناسیم.
          </p>
          <div className="mt-10 grid gap-4 sm:grid-cols-2">
            {[
              { t: "دفتر مرکزی", v: "بلوار نلسون ماندلا، خیابان مریم، پلاک ۲۴" },
              { t: "تماس", v: "+98 21 2266 4400" },
              { t: "ایمیل", v: "hello@demethome.ir" },
              { t: "ساعات کاری", v: "شنبه تا پنجشنبه — ۹ تا ۲۱" },
            ].map((c) => (
              <div key={c.t} className="rounded-[22px] border border-white/10 bg-charcoal/60 p-5">
                <p className="text-[0.65rem] tracking-[0.2em] text-amber">{c.t}</p>
                <p className="mt-2 text-sm leading-7 text-cream" dir={c.t === "تماس" ? "ltr" : undefined}>
                  {c.v}
                </p>
              </div>
            ))}
          </div>
        </Reveal>
        <Reveal delay={140}>
          <InquiryForm />
        </Reveal>
      </section>
    </>
  );
}
