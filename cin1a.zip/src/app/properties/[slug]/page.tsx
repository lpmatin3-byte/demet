import Link from "next/link";
import { notFound } from "next/navigation";
import InquiryForm from "@/components/InquiryForm";
import Parallax from "@/components/Parallax";
import PropertyCard from "@/components/PropertyCard";
import PropertyGallery from "@/components/PropertyGallery";
import Reveal from "@/components/Reveal";
import { CATEGORY_LABEL, DEAL_LABEL, PROPERTY_TYPE_LABEL } from "@/lib/data/seed-data";
import { nearbyOf, POI_TYPE_ICON, POI_TYPE_LABEL } from "@/lib/data/real-media";
import { formatPerM2, formatPriceShort, toFa } from "@/lib/format";
import { getNeighborhood, getProperties, getPropertyBySlug } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function PropertyDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const item = await getPropertyBySlug(slug);
  if (!item) notFound();

  const nb = await getNeighborhood(item.neighborhoodSlug);
  const similar = (await getProperties({ neighborhood: item.neighborhoodSlug, limit: 7 })).filter((p) => p.slug !== slug).slice(0, 3);

  const isSale = item.dealType === "sale";
  const specs = [
    { label: "متراژ", value: `${toFa(item.areaM2)} متر` },
    { label: "اتاق خواب", value: toFa(item.bedrooms) },
    { label: "اتاق", value: toFa(item.rooms) },
    { label: "طبقه", value: `${toFa(item.floor)} از ${toFa(item.totalFloors)}` },
    { label: "سال ساخت", value: toFa(item.buildYear) },
    { label: "کاربری", value: CATEGORY_LABEL[item.category] },
    { label: "نوع ملک", value: PROPERTY_TYPE_LABEL[item.propertyType] },
    { label: "سرویس بهداشتی", value: toFa(item.bathrooms) },
  ];

  const facilities = [
    { label: "پارکینگ", ok: item.hasParking },
    { label: "آسانسور", ok: item.hasElevator },
    { label: "بالکن", ok: item.hasBalcony },
    { label: "حیاط اختصاصی", ok: item.hasYard },
    { label: "بازسازی‌شده", ok: item.isRenovated },
  ];

  return (
    <>
      <Parallax src={item.images[0]} height="min-h-[38vh]" speed={0.1} tint="from-ink via-ink/75 to-ink/95">
        <div className="mx-auto w-full max-w-7xl px-5 pt-24">
          <Link href="/properties" className="text-xs text-amber hover:underline">
            ← بازگشت به آگهی‌ها
          </Link>
          <p className="kicker mt-4">{item.code} • {DEAL_LABEL[item.dealType]}</p>
          <h1 className="display mt-3 text-[clamp(1.6rem,4vw,3rem)] text-cream">{item.title}</h1>
        </div>
      </Parallax>

      <section className="mx-auto max-w-7xl px-5 py-14">
        <div className="grid gap-10 lg:grid-cols-[1.6fr_1fr]">
          <div>
            <PropertyGallery images={item.images} title={item.title} />

            <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {specs.map((s) => (
                <div key={s.label} className="rounded-[20px] border border-white/10 bg-charcoal/60 p-4 text-center">
                  <p className="text-[0.62rem] text-mist">{s.label}</p>
                  <p className="mt-1.5 text-sm font-extrabold text-cream">{s.value}</p>
                </div>
              ))}
            </div>

            <Reveal className="mt-10">
              <h2 className="text-xl font-extrabold text-cream">توضیحات ملک</h2>
              <p className="mt-4 text-sm leading-8 text-mist">{item.description}</p>
              <p className="mt-3 text-sm leading-8 text-mist">
                موقعیت دقیق: {item.address}. برای بازدید حضوری و دریافت نقشهٔ فنی، با کارشناس محله تماس بگیرید.
              </p>
            </Reveal>

            <Reveal className="mt-10">
              <h2 className="text-xl font-extrabold text-cream">موقعیت و دسترسی‌های نزدیک</h2>
              <p className="mt-2 text-xs text-mist">
                مراکز خدماتی، رفاهی و حمل‌ونقل عمومی در محدودهٔ {nb?.name ?? item.address}
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                {nearbyOf(item.neighborhoodSlug, 5).map((poi) => (
                  <div key={poi.name} className="flex items-center justify-between rounded-2xl border border-white/10 bg-charcoal/60 px-4 py-3">
                    <span className="flex items-center gap-2 text-[0.8rem] text-cream">
                      <span>{POI_TYPE_ICON[poi.type]}</span> {poi.name}
                    </span>
                    <span className="text-end">
                      <span className="block text-[0.62rem] text-mist">{POI_TYPE_LABEL[poi.type]}</span>
                      <span className="block text-[0.72rem] font-bold text-amber">{toFa(poi.minutes)} دقیقه</span>
                    </span>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal className="mt-10">
              <h2 className="text-xl font-extrabold text-cream">امکانات</h2>
              <div className="mt-4 flex flex-wrap gap-2">
                {facilities.map((f) => (
                  <span
                    key={f.label}
                    className={`rounded-full border px-4 py-2 text-[0.72rem] ${
                      f.ok ? "border-flame/30 bg-flame/10 text-amber" : "border-white/10 text-mist/60"
                    }`}
                  >
                    {f.ok ? "✓" : "—"} {f.label}
                  </span>
                ))}
                {item.features.map((f) => (
                  <span key={f} className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-[0.72rem] text-cream/80">
                    {f}
                  </span>
                ))}
              </div>
            </Reveal>
          </div>

          <aside className="space-y-6">
            <div className="glass sticky top-24 rounded-[28px] p-6">
              <div className="flex items-center justify-between">
                <span
                  className={`rounded-full px-3 py-1 text-[0.68rem] font-bold ${
                    isSale ? "bg-flame text-ink" : "bg-cream text-ink"
                  }`}
                >
                  {DEAL_LABEL[item.dealType]}
                </span>
                <span className="text-[0.68rem] text-mist">{toFa(item.views)} بازدید</span>
              </div>

              {isSale ? (
                <>
                  <p className="display mt-5 text-3xl text-cream">{formatPriceShort(item.price)}</p>
                  <p className="mt-2 text-sm text-amber">هر متر: {formatPerM2(item.pricePerM2)}</p>
                </>
              ) : (
                <>
                  <p className="mt-5 text-sm text-mist">ودیعه (رهن)</p>
                  <p className="display text-3xl text-cream">{formatPriceShort(item.deposit)}</p>
                  <p className="mt-4 text-sm text-mist">اجارهٔ ماهانه</p>
                  <p className="display text-3xl gold-text">{formatPriceShort(item.rentMonthly)}</p>
                </>
              )}

              {item.source && item.sourceUrl && (
                <a
                  href={item.sourceUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-5 block rounded-2xl border border-gold/30 bg-gold/10 p-4 text-[0.7rem] leading-6 text-gold"
                >
                  ✔ آگهی واقعی — منبع: {item.source} (مهر ۱۴۰۵) مشاهدهٔ نسخهٔ اصلی ↗
                </a>
              )}

              <div className="mt-6 space-y-2 border-t border-white/10 pt-5 text-[0.75rem] text-mist">
                <p className="flex justify-between"><span>محله</span><b className="text-cream">{nb?.name ?? "—"}</b></p>
                <p className="flex justify-between"><span>منطقه</span><b className="text-cream">{nb ? toFa(nb.district) : "—"}</b></p>
                <p className="flex justify-between"><span>روند سالانهٔ محله</span><b className="text-amber">+{nb ? toFa(nb.trendPct) : "—"}٪</b></p>
                <p className="flex justify-between"><span>بازده اجاره</span><b className="text-cream">{nb ? toFa(nb.yieldPct.toFixed(1)) : "—"}٪</b></p>
              </div>

              <a
                href={`tel:+982122664400`}
                className="mt-6 block rounded-2xl bg-gradient-to-l from-gold via-flame to-copper py-3.5 text-center text-sm font-extrabold text-ink"
              >
                تماس با کارشناس محله
              </a>
            </div>

            <InquiryForm propertyCode={item.code} />
          </aside>
        </div>

        {similar.length > 0 && (
          <div className="mt-20">
            <h2 className="display text-2xl text-cream">آگهی‌های مشابه در {nb?.name}</h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {similar.map((p, i) => (
                <Reveal key={p.id} delay={i * 110} variant="blur">
                  <PropertyCard item={p} />
                </Reveal>
              ))}
            </div>
          </div>
        )}
      </section>
    </>
  );
}
