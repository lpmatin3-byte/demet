import Parallax from "@/components/Parallax";
import PropertyExplorer from "@/components/PropertyExplorer";
import { IMG } from "@/lib/data/images";
import { toFa } from "@/lib/format";
import { getMarketSnapshot, getNeighborhoods, getProperties } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "آگهی‌های املاک | Demet Home",
  description: "فیلتر دقیق آگهی‌های فروش و رهن و اجاره در منطقهٔ ۲ و ۳ تهران.",
};

export default async function PropertiesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const pick = (key: string) => {
    const value = sp[key];
    return typeof value === "string" && value.length > 0 ? value : undefined;
  };

  const filters = {
    deal: pick("deal"),
    category: pick("category"),
    type: pick("type"),
    neighborhood: pick("neighborhood"),
    q: pick("q"),
    sort: pick("sort"),
  };

  const [items, neighborhoods, snapshot] = await Promise.all([
    getProperties({ ...filters, limit: 60 }),
    getNeighborhoods(),
    getMarketSnapshot(),
  ]);

  return (
    <>
      <Parallax src={IMG.facadeModern} height="min-h-[46vh]" speed={0.12} tint="from-ink via-ink/70 to-ink/90">
        <div className="mx-auto w-full max-w-7xl px-5 pt-24">
          <p className="kicker">Demet Home Listings</p>
          <h1 className="display mt-4 text-[clamp(2rem,5vw,4rem)] text-cream">
            آگهی‌های <span className="gold-text">شمال تهران</span>
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-8 text-mist">
            {toFa(snapshot.total)} آگهی فعال در {toFa(snapshot.neighborhoods)} محلهٔ منتخب منطقهٔ ۲ و ۳؛ فیلتر ترکیبی
            معامله، کاربری، نوع ملک، محله و متراژ.
          </p>
        </div>
      </Parallax>

      <section className="mx-auto max-w-7xl px-5 py-14">
        <PropertyExplorer
          initialItems={items}
          neighborhoods={neighborhoods.map((n) => ({ slug: n.slug, name: n.name, district: n.district }))}
          initial={filters}
        />
      </section>
    </>
  );
}
