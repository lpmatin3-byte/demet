"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import SmartImage from "./SmartImage";
import type { Building } from "@/db/schema";
import { formatPerM2, formatPriceShort, toFa } from "@/lib/format";

const USAGE_LABEL: Record<string, string> = {
  residential: "مسکونی",
  office: "اداری",
  commercial: "تجاری",
};

export default function BuildingsShowcase({ items }: { items: Building[] }) {
  const [filter, setFilter] = useState<string>("");
  const [open, setOpen] = useState<string | null>(null);

  const areas = useMemo(() => {
    const map = new Map<string, string>();
    items.forEach((b) => map.set(b.neighborhoodSlug, b.neighborhoodSlug));
    return Array.from(map.values());
  }, [items]);

  const list = filter ? items.filter((b) => b.neighborhoodSlug === filter) : items;
  const active = items.find((b) => b.slug === open) ?? null;

  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto pb-2">
        <button
          type="button"
          onClick={() => setFilter("")}
          className={`shrink-0 rounded-full border px-4 py-2 text-[0.72rem] font-bold transition-colors ${
            filter === "" ? "border-copper bg-copper text-linen" : "border-[#14161b]/15 text-[#4a515c] hover:border-copper/50"
          }`}
        >
          همهٔ پروژه‌ها ({toFa(items.length)})
        </button>
        {areas.map((slug) => {
          const count = items.filter((b) => b.neighborhoodSlug === slug).length;
          return (
            <button
              key={slug}
              type="button"
              onClick={() => setFilter(slug)}
              className={`shrink-0 rounded-full border px-4 py-2 text-[0.72rem] font-bold transition-colors ${
                filter === slug ? "border-copper bg-copper text-linen" : "border-[#14161b]/15 text-[#4a515c] hover:border-copper/50"
              }`}
            >
              {slug === "saadat-abad" ? "سعادت‌آباد" : slug === "shahrak-gharb" ? "شهرک غرب" : slug === "jordan" ? "جردن" : slug === "zafar" ? "ظفر" : slug === "vanak" ? "ونک" : slug === "mirdamad" ? "میرداماد" : slug}
              {" "}
              ({toFa(count)})
            </button>
          );
        })}
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((b, i) => (
          <button
            key={b.slug}
            type="button"
            onClick={() => setOpen(b.slug)}
            className="card tilt-card group relative overflow-hidden rounded-[28px] text-start"
            style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
          >
            <div className="relative aspect-[4/3] overflow-hidden">
              <SmartImage
                src={b.images[0]}
                fallback="/images/hero-penthouse.jpg"
                alt={b.name}
                loading={i < 3 ? "eager" : "lazy"}
                className="h-full w-full object-cover transition-transform duration-[1200ms] group-hover:scale-[1.12]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#14161b] via-[#14161b]/25 to-transparent" />
              <div className="absolute right-4 top-4 flex gap-2">
                <span className="rounded-full bg-copper/90 px-3 py-1 text-[0.66rem] font-bold text-linen">
                  {USAGE_LABEL[b.usage]}
                </span>
                {b.isFeatured && (
                  <span className="rounded-full bg-linen/90 px-3 py-1 text-[0.66rem] font-bold text-[#14161b]">شاخص</span>
                )}
              </div>
              <div className="absolute inset-x-4 bottom-4">
                <p className="text-[0.64rem] tracking-[0.2em] text-gold">{b.nameEn}</p>
                <h3 className="text-lg font-extrabold text-cream">{b.name}</h3>
                <p className="mt-1 line-clamp-1 text-[0.68rem] text-cream/70">{b.address}</p>
              </div>
            </div>
            <div className="p-5">
              <div className="grid grid-cols-2 gap-3 text-[0.7rem]">
                <div>
                  <p className="soft">هر متر</p>
                  <p className="mt-1 font-extrabold text-[#14161b]">{formatPerM2(b.salePerM2)}</p>
                </div>
                <div>
                  <p className="soft">شروع قیمت</p>
                  <p className="mt-1 font-extrabold text-[#14161b]">{formatPriceShort(b.priceFrom)}</p>
                </div>
              </div>
              <p className="mt-4 line-clamp-1 text-[0.68rem] text-copper">سازنده: {b.builder}</p>
              <p className="mt-1.5 text-[0.68rem] text-[#4a515c]">
                {toFa(b.yearBuilt)} • {b.floors} • {b.unitSizes}
              </p>
            </div>
          </button>
        ))}
      </div>

      {active && (
        <div
          className="fixed inset-0 z-[80] grid place-items-center bg-[#0d0f13]/85 p-4 backdrop-blur-xl"
          onClick={() => setOpen(null)}
        >
          <div
            className="rise-in max-h-[88vh] w-full max-w-4xl overflow-y-auto rounded-[30px] border border-white/10 bg-charcoal"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative h-56 w-full overflow-hidden rounded-t-[30px]">
              <SmartImage src={active.images[0]} fallback="/images/tehran-aerial.jpg" alt={active.name} loading="eager" className="h-full w-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-charcoal/30 to-transparent" />
              <button
                type="button"
                onClick={() => setOpen(null)}
                className="absolute left-4 top-4 grid h-10 w-10 place-items-center rounded-full bg-ink/70 text-cream backdrop-blur-md"
                aria-label="بستن"
              >
                ✕
              </button>
              <div className="absolute inset-x-6 bottom-5">
                <p className="text-[0.66rem] tracking-[0.28em] text-gold">{active.nameEn}</p>
                <h3 className="display mt-2 text-3xl text-cream">{active.name}</h3>
              </div>
            </div>

            <div className="p-6 sm:p-8">
              <div className="grid gap-3 sm:grid-cols-3">
                {[
                  { k: "هر متر", v: formatPerM2(active.salePerM2) },
                  { k: "شروع قیمت", v: formatPriceShort(active.priceFrom) },
                  { k: "سال ساخت", v: toFa(active.yearBuilt) },
                  { k: "سازنده", v: active.builder },
                  { k: "معمار", v: active.architect },
                  { k: "سبک", v: active.style },
                  { k: "طبقات", v: active.floors },
                  { k: "واحدها", v: active.units },
                  { k: "متراژ واحدها", v: active.unitSizes },
                  { k: "زمین", v: `${toFa(active.landArea)} متر` },
                  { k: "زیربنا", v: `${toFa(active.buildArea)} متر` },
                  { k: "آدرس", v: active.address },
                ].map((row) => (
                  <div key={row.k} className="rounded-2xl border border-white/10 bg-ash/60 p-4">
                    <p className="text-[0.62rem] text-mist">{row.k}</p>
                    <p className="mt-1.5 text-[0.78rem] font-bold leading-6 text-cream">{row.v}</p>
                  </div>
                ))}
              </div>

              {active.rentPerM2 > 0 && (
                <div className="mt-5 rounded-2xl border border-copper/25 bg-copper/10 p-5">
                  <p className="text-[0.66rem] tracking-[0.2em] text-gold">رهن و اجاره (مهر ۱۴۰۵)</p>
                  <div className="mt-3 grid gap-3 sm:grid-cols-3">
                    <p className="text-[0.76rem] text-cream">رهن کامل هر متر: <b>{formatPriceShort(active.rentDepositPerM2)}</b></p>
                    <p className="text-[0.76rem] text-cream">اجارهٔ ماهانهٔ هر متر: <b>{toFa(Math.round(active.rentPerM2 / 1000))} هزار تومان</b></p>
                    <p className="text-[0.76rem] text-cream">نمونهٔ ۲۰۰ متری: <b>رهن {formatPriceShort(active.rentDepositPerM2 * 200)}</b></p>
                  </div>
                </div>
              )}

              <div className="mt-6 grid gap-6 sm:grid-cols-2">
                <div>
                  <h4 className="text-sm font-extrabold text-cream">امکانات</h4>
                  <ul className="mt-3 space-y-2">
                    {active.features.map((f) => (
                      <li key={f} className="flex gap-2 text-[0.76rem] leading-6 text-mist">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-flame" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="text-sm font-extrabold text-cream">دسترسی‌های اطراف</h4>
                  <ul className="mt-3 space-y-2">
                    {active.nearby.map((f) => (
                      <li key={f} className="flex gap-2 text-[0.76rem] leading-6 text-mist">
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <p className="mt-6 text-[0.82rem] leading-8 text-mist">{active.description}</p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  href={`/buildings/${active.slug}`}
                  className="rounded-full bg-gradient-to-l from-gold via-flame to-copper px-6 py-3 text-[0.78rem] font-extrabold text-ink"
                >
                  صفحهٔ اختصاصی پروژه
                </Link>
                <Link
                  href={`/properties?neighborhood=${active.neighborhoodSlug}`}
                  className="rounded-full border border-white/15 px-6 py-3 text-[0.78rem] font-bold text-cream"
                >
                  آگهی‌های این محله
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
