"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";

type Card = { title: string; subtitle: string; href: string; image: string; badge: string };
type Msg = { role: "user" | "bot"; text: string; cards?: Card[]; chips?: string[] };

const WELCOME: Msg = {
  role: "bot",
  text:
    "سلام 👋 من **دیمت‌آی‌آی** هستم، مشاور هوشمند املاک Demet Home.\n\nقیمت هر محله از منطقهٔ ۲ و ۳ تهران، رهن و اجاره، و مسائل حقوقی ملکی را ازم بپرسید.\n\n### مثال\n• یک آپارتمان دو خوابه ۱۰۰ متری در کامکارها می‌خوام، رهن و اجاره‌اش چقدر می‌شه؟",
  chips: [
    "رهن و اجاره ۲ خوابه ۱۰۰ متری کامکارها",
    "قیمت آپارتمان ۱۲۰ متری جردن",
    "قوانین قرارداد اجاره",
    "بهترین محله برای سرمایه‌گذاری",
  ],
};

function Bold({ text }: { text: string }) {
  const parts = text.split("**");
  return (
    <>
      {parts.map((part, i) =>
        i % 2 === 1 ? (
          <strong key={i} className="font-extrabold text-amber">
            {part}
          </strong>
        ) : (
          <span key={i}>{part}</span>
        ),
      )}
    </>
  );
}

function RichText({ text }: { text: string }) {
  return (
    <div className="space-y-2">
      {text.split("\n").map((line, i) => {
        if (!line.trim()) return <div key={i} className="h-1" />;
        if (line.startsWith("### "))
          return (
            <p key={i} className="mt-3 text-[0.72rem] font-bold tracking-[0.18em] text-flame">
              {line.slice(4)}
            </p>
          );
        if (line.startsWith("• ") || line.startsWith("- "))
          return (
            <p key={i} className="flex gap-2 text-[0.82rem] leading-6 text-cream/90">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-flame" />
              <span>
                <Bold text={line.slice(2)} />
              </span>
            </p>
          );
        return (
          <p key={i} className="text-[0.85rem] leading-7 text-cream/90">
            <Bold text={line} />
          </p>
        );
      })}
    </div>
  );
}

export function ChatLauncherButton({ className = "" }: { className?: string }) {
  return (
    <button
      type="button"
      onClick={() => window.dispatchEvent(new Event("demet:open-chat"))}
      className={`rounded-full bg-gradient-to-l from-gold via-flame to-copper px-7 py-3.5 text-sm font-extrabold text-ink transition-transform hover:scale-[1.03] ${className}`}
    >
      گفتگو با مشاور هوشمند ✦
    </button>
  );
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const sessionRef = useRef<string>("");
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    sessionRef.current = Math.random().toString(36).slice(2, 12);
    const handler = () => setOpen(true);
    window.addEventListener("demet:open-chat", handler);
    return () => window.removeEventListener("demet:open-chat", handler);
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, busy, open]);

  const send = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text || busy) return;
      setInput("");
      setMessages((m) => [...m, { role: "user", text }]);
      setBusy(true);
      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ message: text, sessionId: sessionRef.current }),
        });
        const data = (await res.json()) as {
          ok: boolean;
          reply?: string;
          cards?: Card[];
          chips?: string[];
          error?: string;
        };
        setMessages((m) => [
          ...m,
          {
            role: "bot",
            text: data.reply ?? (data.ok ? "متوجه نشدم، لطفاً دقیق‌تر بپرسید." : `خطا: ${data.error ?? "نامشخص"}`),
            cards: data.cards ?? [],
            chips: data.chips ?? [],
          },
        ]);
      } catch {
        setMessages((m) => [...m, { role: "bot", text: "ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید." }]);
      } finally {
        setBusy(false);
      }
    },
    [busy],
  );

  return (
    <>
      {/* launcher */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="group fixed bottom-5 left-5 z-[70] flex items-center gap-3 rounded-full border border-flame/40 bg-ink/85 p-2 pe-5 backdrop-blur-xl transition-all hover:border-flame hover:shadow-glow"
        aria-label="مشاور هوشمند"
      >
        <span className="relative grid h-12 w-12 place-items-center rounded-full bg-gradient-to-br from-gold via-flame to-copper text-xl">
          <span className="absolute inset-0 rounded-full bg-flame/40 pulse-ring" />
          🤖
        </span>
        <span className="hidden text-start sm:block">
          <span className="block text-sm font-bold text-cream">مشاور هوشمند</span>
          <span className="block text-[0.65rem] text-mist">قیمت لحظه‌ای • حقوقی • جستجو</span>
        </span>
      </button>

      {/* panel */}
      {open && (
        <div className="fixed bottom-24 left-4 z-[70] flex h-[min(78vh,620px)] w-[min(94vw,412px)] rise-in flex-col overflow-hidden rounded-[28px] border border-white/12 bg-charcoal/95 shadow-lift backdrop-blur-2xl">
          <div className="relative flex items-center justify-between gap-3 border-b border-white/10 bg-gradient-to-l from-flame/20 to-transparent px-5 py-4">
            <div>
              <p className="text-sm font-extrabold text-cream">دیمت‌آی‌آی • Demet AI</p>
              <p className="text-[0.65rem] text-amber">اتصال برقرار • دادهٔ منطقه ۲ و ۳ تهران</p>
            </div>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="grid h-8 w-8 place-items-center rounded-full border border-white/15 text-mist hover:text-cream"
              aria-label="بستن"
            >
              ✕
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 space-y-4 overflow-y-auto px-4 py-4">
            {messages.map((m, i) => (
              <div key={i} className={m.role === "user" ? "flex justify-start" : "flex justify-end"}>
                <div
                  className={`max-w-[88%] rounded-3xl px-4 py-3 ${
                    m.role === "user"
                      ? "bg-flame/90 text-ink"
                      : "border border-white/10 bg-ash/80 text-cream"
                  }`}
                >
                  {m.role === "user" ? (
                    <p className="text-[0.85rem] leading-7 font-medium">{m.text}</p>
                  ) : (
                    <RichText text={m.text} />
                  )}

                  {!!m.cards?.length && (
                    <div className="mt-3 space-y-2">
                      {m.cards.map((c) => (
                        <Link
                          key={c.href}
                          href={c.href}
                          className="flex items-center gap-3 rounded-2xl border border-white/10 bg-ink/60 p-2 transition-colors hover:border-flame/50"
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img src={c.image} alt={c.title} className="h-14 w-16 rounded-xl object-cover" />
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[0.78rem] font-bold text-cream">{c.title}</span>
                            <span className="block truncate text-[0.68rem] text-amber">{c.subtitle}</span>
                          </span>
                        </Link>
                      ))}
                    </div>
                  )}

                  {!!m.chips?.length && (
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {m.chips.slice(0, 4).map((chip) => (
                        <button
                          key={chip}
                          type="button"
                          onClick={() => send(chip)}
                          className="rounded-full border border-flame/30 bg-flame/10 px-3 py-1.5 text-[0.66rem] text-amber transition-colors hover:bg-flame hover:text-ink"
                        >
                          {chip}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {busy && (
              <div className="flex justify-end">
                <div className="flex items-center gap-1.5 rounded-3xl border border-white/10 bg-ash/80 px-4 py-3">
                  {[0, 1, 2].map((d) => (
                    <span
                      key={d}
                      className="typing-dot h-2 w-2 rounded-full bg-flame"
                      style={{ animationDelay: `${d * 0.16}s` }}
                    />
                  ))}
                  <span className="ms-1 text-[0.7rem] text-mist">در حال تحلیل بازار…</span>
                </div>
              </div>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              void send(input);
            }}
            className="flex items-center gap-2 border-t border-white/10 bg-ink/60 p-3"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="مثلاً: رهن و اجاره ۲ خوابه ۱۰۰ متری ونک"
              className="flex-1 rounded-2xl border border-white/12 bg-ash/70 px-4 py-3 text-[0.82rem] text-cream outline-none transition-colors placeholder:text-mist/60 focus:border-flame/60"
            />
            <button
              type="submit"
              disabled={busy || !input.trim()}
              className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-gold to-flame text-lg text-ink transition-opacity disabled:opacity-40"
              aria-label="ارسال"
            >
              ➤
            </button>
          </form>
        </div>
      )}
    </>
  );
}
