"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { CINEMATIC_BACKGROUNDS } from "@/lib/data/images";
import { CATEGORY_TABS, DEAL_TABS, TYPE_TABS, toFa } from "@/lib/format";

const SCENE_TEXT = [
  { kicker: "Demet Home — North Tehran", title: "زندگی، در بالاترین\nنقطهٔ تهران", sub: "املاک لوکس منطقهٔ ۲ و ۳ — ونک، جردن، میرداماد، ظفر، سعادت‌آباد، شهرک غرب و شیخ بهایی." },
  { kicker: "Cinematic Living", title: "نور، فضا،\nو سکوتِ مطلق", sub: "واحدهای منتخب با نورگیری کامل، نمای باز و معماری مینیمال." },
  { kicker: "Penthouse Collection", title: "پنت‌هاوس‌هایی\nبا نمای شهر", sub: "تراس‌های خصوصی، استخر روف‌تاپ و لابی منشن در برج‌های شمال تهران." },
  { kicker: "Signature Villas", title: "سنگ، شیشه\nو هارمونی گرم", sub: "ویلاهای دوبلکس و سه‌طبقه در سعادت‌آباد، دروس و شهرک غرب." },
  { kicker: "District 2 & 3 Map", title: "نقشهٔ سه‌بعدی\nمحله‌های شمال", sub: "محلهٔ مورد نظرتان را روی نقشهٔ متحرک انتخاب کنید و قیمت لحظه‌ای را ببینید." },
  { kicker: "Demet AI Advisor", title: "مشاورِ هوشمندی\nکه قیمت را می‌داند", sub: "متراژ و محله را بگویید؛ رهن، اجاره و قیمت فروش را همان لحظه تحلیل می‌کند." },
];

export default function CinematicHero({ stats }: { stats: { total: number; sale: number; rent: number; neighborhoods: number } }) {
  const router = useRouter();
  const [scene, setScene] = useState(0);
  const [progress, setProgress] = useState(0);

  const [deal, setDeal] = useState("sale");
  const [category, setCategory] = useState("residential");
  const [type, setType] = useState("apartment");
  const [nb, setNb] = useState("");

  const neighborhoods = useMemo(
    () => [
      { slug: "", name: "همهٔ محله‌ها" },
      { slug: "vanak", name: "ونک" },
      { slug: "jordan", name: "جردن" },
      { slug: "mirdamad", name: "میرداماد" },
      { slug: "zafar", name: "ظفر" },
      { slug: "elahieh", name: "الهیه" },
      { slug: "farmanieh", name: "فرمانیه" },
      { slug: "saadat-abad", name: "سعادت‌آباد" },
      { slug: "shahrak-gharb", name: "شهرک غرب" },
      { slug: "sheikh-bahaei", name: "شیخ بهایی" },
      { slug: "kamkarha", name: "کامکارها" },
      { slug: "marzdaran", name: "مرزداران" },
    ],
    [],
  );

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const zone = document.getElementById("cine-zone");
        if (!zone) return;
        const h = window.innerHeight;
        const total = zone.offsetHeight - h;
        const p = Math.min(1, Math.max(0, -zone.getBoundingClientRect().top / Math.max(1, total)));
        setProgress(p);
        setScene(Math.min(SCENE_TEXT.length - 1, Math.floor(p * SCENE_TEXT.length)));
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  const current = SCENE_TEXT[scene];

  const submit = () => {
    const params = new URLSearchParams({ deal, category, type });
    if (nb) params.set("neighborhood", nb);
    router.push(`/properties?${params.toString()}`);
  };

  return (
    <section id="cine-zone" className="relative h-[440vh]">
      <div className="sticky top-0 h-[100svh] overflow-hidden grain vignette">
        {/* cinematic background layers */}
        {CINEMATIC_BACKGROUNDS.map((bg, i) => (
          <div
            key={bg.src}
            className={`cine-layer ${i === scene ? "active" : ""}`}
            hidden={Math.abs(i - scene) > 1}
            style={{
              backgroundImage: `url(${bg.src})`,
              transform: `scale(${1.05 + progress * 0.12})`,
              transitionDelay: `${i === scene ? 0 : 300}ms`,
            }}
          />
        ))}

        {/* color harmony wash */}
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-ink/70" />
        <div className="absolute inset-0 mix-blend-soft-light opacity-70 bg-[radial-gradient(80%_60%_at_20%_10%,rgba(249,115,22,0.35),transparent_60%),radial-gradient(70%_50%_at_90%_90%,rgba(251,191,36,0.22),transparent_60%)]" />

        {/* scene rail */}
        <div className="absolute left-5 top-1/2 z-20 hidden -translate-y-1/2 flex-col gap-3 md:flex">
          {SCENE_TEXT.map((s, i) => (
            <button
              key={s.title}
              type="button"
              onClick={() => {
                const zone = document.getElementById("cine-zone");
                if (!zone) return;
                const h = window.innerHeight;
                window.scrollTo({ top: zone.offsetTop + ((zone.offsetHeight - h) * i) / SCENE_TEXT.length, behavior: "smooth" });
              }}
              className="group flex items-center gap-2"
              aria-label={CINEMATIC_BACKGROUNDS[i].label}
            >
              <span
                className={`h-[2px] rounded-full transition-all duration-500 ${
                  i === scene ? "w-10 bg-flame" : "w-4 bg-cream/30 group-hover:bg-cream/60"
                }`}
              />
              <span
                className={`text-[0.6rem] tracking-[0.2em] transition-all duration-500 ${
                  i === scene ? "text-amber opacity-100" : "text-mist opacity-0 group-hover:opacity-100"
                }`}
              >
                {CINEMATIC_BACKGROUNDS[i].label}
              </span>
            </button>
          ))}
        </div>

        {/* content */}
        <div className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-center px-5 pt-24">
          <div key={scene} className="rise-in max-w-3xl">
            <p className="kicker">{current.kicker}</p>
            <h1 className="display mt-6 text-[clamp(2.4rem,7.4vw,5.6rem)] whitespace-pre-line text-cream">
              {current.title.split("\n").map((line, i) => (
                <span key={i} className={i === 1 ? "gold-text block" : "block"}>
                  {line}
                </span>
              ))}
            </h1>
            <p className="mt-6 max-w-xl text-[0.95rem] leading-8 text-cream/70">{current.sub}</p>
          </div>

          {/* search console */}
          <div className="mt-10 w-full max-w-4xl">
            <div className="glass rounded-[26px] p-2.5">
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex rounded-2xl bg-ink/60 p-1">
                  {DEAL_TABS.map((t) => (
                    <button
                      key={t.value}
                      type="button"
                      onClick={() => setDeal(t.value)}
                      className={`rounded-xl px-4 py-2 text-[0.78rem] font-bold transition-all ${
                        deal === t.value ? "bg-flame text-ink" : "text-mist hover:text-cream"
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.78rem] text-cream outline-none focus:border-flame/60"
                >
                  {CATEGORY_TABS.map((t) => (
                    <option key={t.value} value={t.value} className="bg-charcoal">
                      {t.label}
                    </option>
                  ))}
                </select>

                <select
                  value={type}
                  onChange={(e) => setType(e.target.value)}
                  className="rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.78rem] text-cream outline-none focus:border-flame/60"
                >
                  <option value="" className="bg-charcoal">
                    همهٔ انواع ملک
                  </option>
                  {TYPE_TABS.map((t) => (
                    <option key={t.value} value={t.value} className="bg-charcoal">
                      {t.label}
                    </option>
                  ))}
                </select>

                <select
                  value={nb}
                  onChange={(e) => setNb(e.target.value)}
                  className="min-w-[9.5rem] flex-1 rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.78rem] text-cream outline-none focus:border-flame/60"
                >
                  {neighborhoods.map((n) => (
                    <option key={n.slug} value={n.slug} className="bg-charcoal">
                      {n.name}
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={submit}
                  className="rounded-2xl bg-gradient-to-l from-gold via-flame to-copper px-7 py-3 text-[0.82rem] font-extrabold text-ink transition-transform hover:scale-[1.03]"
                >
                  جستجوی سینمایی ✦
                </button>
              </div>
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-x-8 gap-y-3 text-[0.72rem] text-mist">
              <span>
                <b className="text-cream">{toFa(stats.total)}</b> آگهی فعال
              </span>
              <span>
                <b className="text-cream">{toFa(stats.sale)}</b> فروش
              </span>
              <span>
                <b className="text-cream">{toFa(stats.rent)}</b> رهن و اجاره
              </span>
              <span>
                <b className="text-cream">{toFa(stats.neighborhoods)}</b> محلهٔ منتخب
              </span>
              <Link href="#map" className="text-amber underline decoration-flame/40 underline-offset-4">
                نقشهٔ سه‌بعدی تهران ↗
              </Link>
            </div>
          </div>
        </div>

        {/* bottom progress */}
        <div className="absolute bottom-6 inset-x-5 z-10 mx-auto max-w-7xl">
          <div className="flex items-center gap-4">
            <span className="text-[0.6rem] tracking-[0.3em] text-mist">
              {CINEMATIC_BACKGROUNDS[scene].label}
            </span>
            <div className="relative h-[3px] flex-1 overflow-hidden rounded-full bg-cream/15">
              <div
                className="absolute inset-y-0 right-0 bg-gradient-to-l from-gold to-flame"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
            <span className="text-[0.6rem] tracking-[0.3em] text-mist">
              {toFa(scene + 1)} / {toFa(SCENE_TEXT.length)}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
