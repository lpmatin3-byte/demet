"use client";

import { useState } from "react";

export default function InquiryForm({ propertyCode }: { propertyCode?: string }) {
  const [form, setForm] = useState({ name: "", phone: "", message: "" });
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setState("sending");
    try {
      const res = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...form, propertyCode }),
      });
      const data = (await res.json()) as { ok: boolean; error?: string };
      if (!data.ok) throw new Error(data.error ?? "خطا در ارسال");
      setState("done");
      setForm({ name: "", phone: "", message: "" });
    } catch (err) {
      setError((err as Error).message);
      setState("error");
    }
  };

  if (state === "done") {
    return (
      <div className="glass rounded-[28px] p-8 text-center">
        <p className="text-4xl">✦</p>
        <h3 className="mt-4 text-xl font-extrabold text-cream">درخواست شما ثبت شد</h3>
        <p className="mt-3 text-sm leading-7 text-mist">
          کارشناسان Demet Home حداکثر تا ۲ ساعت کاری با شما تماس می‌گیرند.
        </p>
        <button
          type="button"
          onClick={() => setState("idle")}
          className="mt-6 rounded-full border border-flame/40 px-6 py-2.5 text-sm text-amber hover:bg-flame hover:text-ink"
        >
          ثبت درخواست جدید
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="glass rounded-[28px] p-6 sm:p-8">
      <h3 className="text-xl font-extrabold text-cream">درخواست مشاورهٔ اختصاصی</h3>
      <p className="mt-2 text-xs leading-6 text-mist">
        {propertyCode ? `برای آگهی ${propertyCode} ` : ""}فرم را پر کنید؛ کارشناس محلهٔ مورد نظر با شما تماس می‌گیرد.
      </p>

      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <input
          required
          minLength={2}
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          placeholder="نام و نام خانوادگی"
          className="rounded-2xl border border-white/12 bg-ink/60 px-4 py-3.5 text-sm text-cream outline-none placeholder:text-mist/60 focus:border-flame/60"
        />
        <input
          required
          minLength={8}
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          placeholder="شمارهٔ تماس"
          inputMode="tel"
          className="rounded-2xl border border-white/12 bg-ink/60 px-4 py-3.5 text-sm text-cream outline-none placeholder:text-mist/60 focus:border-flame/60"
        />
      </div>
      <textarea
        rows={4}
        value={form.message}
        onChange={(e) => setForm({ ...form, message: e.target.value })}
        placeholder="توضیح کوتاه: محله، متراژ، بودجه، نوع معامله…"
        className="mt-3 w-full rounded-2xl border border-white/12 bg-ink/60 px-4 py-3.5 text-sm leading-7 text-cream outline-none placeholder:text-mist/60 focus:border-flame/60"
      />

      {state === "error" && <p className="mt-3 text-xs text-flame">{error}</p>}

      <button
        type="submit"
        disabled={state === "sending"}
        className="mt-5 w-full rounded-2xl bg-gradient-to-l from-gold via-flame to-copper py-4 text-sm font-extrabold text-ink transition-transform hover:scale-[1.01] disabled:opacity-50"
      >
        {state === "sending" ? "در حال ارسال…" : "ارسال درخواست"}
      </button>
    </form>
  );
}
