type Props = { className?: string; showWordmark?: boolean; compact?: boolean };

export function Logo({ className = "", showWordmark = true, compact = false }: Props) {
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <svg
        viewBox="0 0 48 48"
        className={compact ? "h-8 w-8" : "h-11 w-11"}
        aria-hidden="true"
        role="img"
      >
        <defs>
          <linearGradient id="dmt-g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FBBF24" />
            <stop offset="52%" stopColor="#F97316" />
            <stop offset="100%" stopColor="#C2661F" />
          </linearGradient>
        </defs>
        <rect x="1" y="1" width="46" height="46" rx="13" fill="none" stroke="url(#dmt-g)" strokeWidth="1.6" opacity="0.75" />
        {/* roof / house mark */}
        <path d="M12 25.5 L24 13.5 L36 25.5" fill="none" stroke="url(#dmt-g)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M16.5 26.5 V35.5 H31.5 V26.5" fill="none" stroke="#F7F0E6" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" opacity="0.92" />
        {/* D monogram dot */}
        <circle cx="24" cy="31" r="2.1" fill="url(#dmt-g)" />
      </svg>
      {showWordmark && (
        <span className="flex flex-col leading-none">
          <span className="text-[1.05rem] font-extrabold tracking-[0.16em] text-cream">DEMET</span>
          <span className="mt-0.5 text-[0.6rem] font-medium tracking-[0.52em] text-amber">HOME</span>
        </span>
      )}
    </span>
  );
}

export default Logo;
