"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";

type Props = {
  src: string;
  children?: ReactNode;
  height?: string;
  speed?: number;
  className?: string;
  tint?: string;
};

export default function Parallax({
  src,
  children,
  height = "min-h-[78vh]",
  speed = 0.18,
  className = "",
  tint = "from-ink via-ink/45 to-ink/80",
}: Props) {
  const ref = useRef<HTMLElement | null>(null);
  const [offset, setOffset] = useState(0);
  const visible = useRef(true);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const io = new IntersectionObserver(
      (entries) => {
        visible.current = entries[0]?.isIntersecting ?? true;
      },
      { rootMargin: "160px" },
    );
    io.observe(node);
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    let raf = 0;
    let queued = false;
    const onScroll = () => {
      if (queued || !visible.current) return;
      queued = true;
      raf = requestAnimationFrame(() => {
        queued = false;
        const node = ref.current;
        if (!node || !visible.current) return;
        const rect = node.getBoundingClientRect();
        const h = window.innerHeight || 1;
        const p = (rect.top + rect.height / 2 - h / 2) / h;
        setOffset(p * speed * 100);
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
    };
  }, [speed]);

  return (
    <section ref={ref} className={`relative overflow-hidden ${height} ${className}`}>
      <div
        className="absolute -inset-y-[22%] inset-x-0 bg-cover bg-center will-change-transform"
        style={{
          backgroundImage: `url(${src})`,
          transform: `translate3d(0, ${offset.toFixed(2)}%, 0) scale(1.08)`,
        }}
      />
      <div className={`absolute inset-0 bg-gradient-to-b ${tint}`} />
      <div className="absolute inset-0 bg-[radial-gradient(70%_60%_at_75%_20%,rgba(249,115,22,0.22),transparent_60%)] mix-blend-soft-light" />
      <div className="relative z-10 flex h-full items-center">{children}</div>
    </section>
  );
}
