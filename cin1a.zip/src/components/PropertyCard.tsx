import Link from "next/link";
import SmartImage from "./SmartImage";
import type { Property } from "@/db/schema";
import { formatPerM2, formatPriceShort, toFa } from "@/lib/format";
import { CATEGORY_LABEL, DEAL_LABEL, PROPERTY_TYPE_LABEL } from "@/lib/data/seed-data";
import { nearbyOf, POI_TYPE_ICON } from "@/lib/data/real-media";

const TYPE_ICON: Record<string, string> = {
  apartment: "🏢",
  villa: "🏡",
  mixed: "🏛️",
  old: "🧱",
  shop: "🛍️",
};

export function PropertyCard({ item, priority = false }: { item: Property; priority?: boolean }) {
  const isSale = item.dealType === "sale";
  return (
    <Link
      href={`/properties/${item.slug}`}
      className="tilt-card group relative flex flex-col overflow-hidden rounded-[28px] border border-white/10 bg-charcoal/70"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <SmartImage
          src={item.images[0]}
          fallback="/images/hero-villa.jpg"
          alt={item.title}
          loading={priority ? "eager" : "lazy"}
          className="h-full w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.12]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/25 to-transparent" />

        <div className="absolute right-4 top-4 flex flex-wrap gap-2">
          <span
            className={`rounded-full px-3 py-1 text-[0.68rem] font-bold backdrop-blur-md ${
              isSale ? "bg-flame/90 text-ink" : "bg-cream/90 text-ink"
            }`}
          >
            {DEAL_LABEL[item.dealType]}
          </span>
          <span className="rounded-full bg-ink/70 px-3 py-1 text-[0.68rem] font-medium text-cream backdrop-blur-md">
            {TYPE_ICON[item.propertyType]} {PROPERTY_TYPE_LABEL[item.propertyType]}
          </span>
        </div>

        <div className="absolute bottom-4 right-4 left-4 flex items-end justify-between gap-3">
          <div>
            <p className="text-[0.68rem] tracking-[0.2em] text-amber">{item.code}</p>
            <p className="text-lg font-extrabold leading-tight text-cream">
              {isSale ? formatPriceShort(item.price) : `رهن ${formatPriceShort(item.deposit)}`}
            </p>
            {!isSale && (
              <p className="text-sm font-semibold text-amber">اجاره {formatPriceShort(item.rentMonthly)}</p>
            )}
          </div>
          <div className="rounded-2xl bg-ink/70 px-3 py-1.5 text-center backdrop-blur-md">
            <p className="text-[0.6rem] text-mist">متراژ</p>
            <p className="text-sm font-bold text-cream">{toFa(item.areaM2)}</p>
          </div>
        </div>
      </div>

      <div className="flex flex-1 flex-col gap-4 p-5">
        <div>
          <h3 className="line-clamp-1 text-base font-bold text-cream transition-colors group-hover:text-amber">
            {item.title}
          </h3>
          <p className="mt-1.5 line-clamp-1 text-xs text-mist">{item.address}</p>
        </div>

        <div className="mt-auto grid grid-cols-3 gap-2 border-t border-white/10 pt-4 text-center text-[0.7rem] text-mist">
          <div>
            <p className="font-bold text-cream">{toFa(item.rooms)} خواب</p>
            <p className="mt-0.5">اتاق</p>
          </div>
          <div>
            <p className="font-bold text-cream">{toFa(item.buildYear)}</p>
            <p className="mt-0.5">سال ساخت</p>
          </div>
          <div>
            <p className="font-bold text-cream">{toFa(item.floor)}</p>
            <p className="mt-0.5">طبقه</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {nearbyOf(item.neighborhoodSlug, 3).map((poi) => (
            <span
              key={poi.name}
              className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[0.6rem] text-mist"
            >
              {POI_TYPE_ICON[poi.type]} {poi.name} {toFa(poi.minutes)}′
            </span>
          ))}
        </div>

        <div className="flex items-center justify-between text-[0.7rem]">
          <span className="text-mist">{CATEGORY_LABEL[item.category]}</span>
          <span className="font-bold text-amber">{isSale ? formatPerM2(item.pricePerM2) : "رهن و اجاره"}</span>
        </div>
      </div>
    </Link>
  );
}

export default PropertyCard;
