"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import PropertyCard from "@/components/PropertyCard";
import type { Property } from "@/db/schema";
import { CATEGORY_TABS, DEAL_TABS, TYPE_TABS, toFa } from "@/lib/format";

type Option = { value: string; label: string };

export type ExplorerProps = {
  initialItems: Property[];
  neighborhoods: Array<{ slug: string; name: string; district: number }>;
  initial: { deal?: string; category?: string; type?: string; neighborhood?: string; q?: string; sort?: string };
};

const SORTS: Option[] = [
  { value: "featured", label: "شاخص‌ترین" },
  { value: "new", label: "نوسازترین" },
  { value: "price_desc", label: "گران‌ترین" },
  { value: "price_asc", label: "ارزان‌ترین" },
  { value: "area", label: "بزرگ‌ترین متراژ" },
];

const AREAS: Option[] = [
  { value: "", label: "هر متراژی" },
  { value: "0-80", label: "تا ۸۰ متر" },
  { value: "80-120", label: "۸۰ تا ۱۲۰ متر" },
  { value: "120-200", label: "۱۲۰ تا ۲۰۰ متر" },
  { value: "200-9999", label: "بالای ۲۰۰ متر" },
];

export default function PropertyExplorer({ initialItems, neighborhoods, initial }: ExplorerProps) {
  const [deal, setDeal] = useState(initial.deal ?? "");
  const [category, setCategory] = useState(initial.category ?? "");
  const [type, setType] = useState(initial.type ?? "");
  const [neighborhood, setNeighborhood] = useState(initial.neighborhood ?? "");
  const [area, setArea] = useState("");
  const [q, setQ] = useState(initial.q ?? "");
  const [sort, setSort] = useState(initial.sort ?? "featured");
  const [items, setItems] = useState<Property[]>(initialItems);
  const [loading, setLoading] = useState(false);

  const nbOptions = useMemo(
    () => [{ value: "", label: "همهٔ محله‌ها" }, ...neighborhoods.map((n) => ({ value: n.slug, label: `${n.name} (منطقه ${toFa(n.district)})` }))],
    [neighborhoods],
  );

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (deal) params.set("deal", deal);
    if (category) params.set("category", category);
    if (type) params.set("type", type);
    if (neighborhood) params.set("neighborhood", neighborhood);
    if (q.trim()) params.set("q", q.trim());
    if (sort) params.set("sort", sort);
    const [minArea, maxArea] = area.split("-");
    if (minArea) params.set("minArea", minArea);
    if (maxArea) params.set("maxArea", maxArea);
    params.set("limit", "60");
    try {
      const res = await fetch(`/api/properties?${params.toString()}`);
      const data = (await res.json()) as { ok: boolean; items: Property[] };
      setItems(data.items ?? []);
      const url = params.toString();
      window.history.replaceState(null, "", url ? `/properties?${url}` : "/properties");
    } finally {
      setLoading(false);
    }
  }, [deal, category, type, neighborhood, q, sort, area]);

  useEffect(() => {
    const timer = setTimeout(() => void load(), 260);
    return () => clearTimeout(timer);
  }, [load]);

  const activeFilters = [deal, category, type, neighborhood, area, q].filter(Boolean).length;

  return (
    <div>
      <div className="glass sticky top-20 z-30 rounded-[26px] p-4">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-2xl bg-ink/60 p-1">
            {[{ value: "", label: "همه" }, ...DEAL_TABS].map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => setDeal(t.value)}
                className={`rounded-xl px-4 py-2 text-[0.75rem] font-bold transition-all ${
                  deal === t.value ? "bg-flame text-ink" : "text-mist hover:text-cream"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex rounded-2xl bg-ink/60 p-1">
            {[{ value: "", label: "همهٔ کاربری‌ها" }, ...CATEGORY_TABS].map((t) => (
              <button
                key={t.value}
                type="button"
                onClick={() => setCategory(t.value)}
                className={`rounded-xl px-3.5 py-2 text-[0.75rem] font-bold transition-all ${
                  category === t.value ? "bg-cream text-ink" : "text-mist hover:text-cream"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.75rem] text-cream outline-none focus:border-flame/60"
          >
            <option value="" className="bg-charcoal">همهٔ انواع ملک</option>
            {TYPE_TABS.map((t) => (
              <option key={t.value} value={t.value} className="bg-charcoal">
                {t.label}
              </option>
            ))}
          </select>

          <select
            value={neighborhood}
            onChange={(e) => setNeighborhood(e.target.value)}
            className="rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.75rem] text-cream outline-none focus:border-flame/60"
          >
            {nbOptions.map((n) => (
              <option key={n.value} value={n.value} className="bg-charcoal">
                {n.label}
              </option>
            ))}
          </select>

          <select
            value={area}
            onChange={(e) => setArea(e.target.value)}
            className="rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.75rem] text-cream outline-none focus:border-flame/60"
          >
            {AREAS.map((a) => (
              <option key={a.value} value={a.value} className="bg-charcoal">
                {a.label}
              </option>
            ))}
          </select>

          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.75rem] text-cream outline-none focus:border-flame/60"
          >
            {SORTS.map((s) => (
              <option key={s.value} value={s.value} className="bg-charcoal">
                {s.label}
              </option>
            ))}
          </select>

          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جستجو در عنوان و آدرس…"
            className="min-w-[12rem] flex-1 rounded-2xl border border-white/10 bg-ink/70 px-4 py-2.5 text-[0.75rem] text-cream outline-none placeholder:text-mist/60 focus:border-flame/60"
          />

          {activeFilters > 0 && (
            <button
              type="button"
              onClick={() => {
                setDeal("");
                setCategory("");
                setType("");
                setNeighborhood("");
                setArea("");
                setQ("");
              }}
              className="rounded-2xl border border-flame/40 px-4 py-2.5 text-[0.72rem] font-bold text-amber hover:bg-flame hover:text-ink"
            >
              پاک‌کردن {toFa(activeFilters)} فیلتر
            </button>
          )}
        </div>
      </div>

      <div className="mt-8 flex items-center justify-between gap-4 text-sm text-mist">
        <p>
          <b className="text-cream">{toFa(items.length)}</b> آگهی پیدا شد
          {loading ? " • در حال به‌روزرسانی…" : ""}
        </p>
        <div className="hidden gap-1 sm:flex">
          {TYPE_TABS.map((t) => (
            <button
              key={t.value}
              type="button"
              onClick={() => setType(type === t.value ? "" : t.value)}
              className={`rounded-full border px-3.5 py-1.5 text-[0.68rem] transition-colors ${
                type === t.value ? "border-flame bg-flame text-ink" : "border-white/10 text-mist hover:text-cream"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {items.length === 0 ? (
        <div className="mt-16 rounded-[28px] border border-white/10 bg-charcoal/60 p-14 text-center">
          <p className="text-4xl">🔍</p>
          <h3 className="mt-4 text-xl font-extrabold text-cream">آگهی‌ای با این فیلترها نداریم</h3>
          <p className="mt-3 text-sm text-mist">فیلترها را ساده‌تر کنید یا با مشاور هوشمند صحبت کنید تا گزینهٔ مناسب را پیدا کنیم.</p>
        </div>
      ) : (
        <div className={`mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 ${loading ? "opacity-60" : ""} transition-opacity`}>
          {items.map((p, i) => (
            <div key={p.id} className="rise-in" style={{ animationDelay: `${Math.min(i, 8) * 45}ms` }}>
              <PropertyCard item={p} priority={i < 3} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
