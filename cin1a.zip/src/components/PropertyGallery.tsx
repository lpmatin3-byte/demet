"use client";

import { useState } from "react";

export default function PropertyGallery({ images, title }: { images: string[]; title: string }) {
  const [index, setIndex] = useState(0);
  const [zoom, setZoom] = useState(false);
  const safe = images.length ? images : ["/images/hero-villa.jpg"];

  return (
    <div>
      <div
        className="relative aspect-[16/10] overflow-hidden rounded-[30px] border border-white/10"
        onClick={() => setZoom(true)}
        style={{ cursor: "zoom-in" }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img key={safe[index]} src={safe[index]} alt={title} className="h-full w-full object-cover rise-in" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
        <div className="absolute bottom-4 right-4 flex items-center gap-2">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIndex((i) => (i - 1 + safe.length) % safe.length);
            }}
            className="grid h-10 w-10 place-items-center rounded-full bg-ink/70 text-cream backdrop-blur-md hover:bg-flame hover:text-ink"
            aria-label="قبلی"
          >
            ›
          </button>
          <span className="rounded-full bg-ink/70 px-3 py-1.5 text-[0.7rem] text-cream backdrop-blur-md">
            {index + 1} / {safe.length}
          </span>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIndex((i) => (i + 1) % safe.length);
            }}
            className="grid h-10 w-10 place-items-center rounded-full bg-ink/70 text-cream backdrop-blur-md hover:bg-flame hover:text-ink"
            aria-label="بعدی"
          >
            ‹
          </button>
        </div>
      </div>

      <div className="no-scrollbar mt-4 flex gap-3 overflow-x-auto">
        {safe.map((img, i) => (
          <button
            key={img + i}
            type="button"
            onClick={() => setIndex(i)}
            className={`relative h-20 w-28 shrink-0 overflow-hidden rounded-2xl border transition-all ${
              i === index ? "border-flame" : "border-white/10 opacity-60 hover:opacity-100"
            }`}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img} alt={`${title} ${i + 1}`} className="h-full w-full object-cover" />
          </button>
        ))}
      </div>

      {zoom && (
        <div
          className="fixed inset-0 z-[90] grid place-items-center bg-ink/95 p-4 backdrop-blur-xl"
          onClick={() => setZoom(false)}
          style={{ cursor: "zoom-out" }}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={safe[index]} alt={title} className="max-h-[88vh] max-w-full rounded-[24px] object-contain rise-in" />
          <button
            type="button"
            className="absolute top-6 left-6 grid h-11 w-11 place-items-center rounded-full border border-white/20 text-cream"
            aria-label="بستن"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
}
