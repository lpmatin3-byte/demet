"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import Logo from "./Logo";

const NAV = [
  { href: "/", label: "خانه" },
  { href: "/properties?deal=sale", label: "خرید" },
  { href: "/properties?deal=rent", label: "رهن و اجاره" },
  { href: "/#map", label: "نقشهٔ محله‌ها" },
  { href: "/#insights", label: "تحلیل بازار" },
];

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-700 ${
        scrolled ? "bg-ink/85 backdrop-blur-xl border-b border-white/10 py-2" : "bg-transparent py-5"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5">
        <Link href="/" className="shrink-0" aria-label="Demet Home">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="group relative rounded-full px-4 py-2 text-sm font-medium text-mist transition-colors hover:text-cream"
            >
              {item.label}
              <span className="absolute inset-x-4 -bottom-0.5 h-px scale-x-0 bg-gradient-to-r from-transparent via-flame to-transparent transition-transform duration-500 group-hover:scale-x-100" />
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            href="/properties"
            className="hidden rounded-full border border-flame/40 bg-flame/10 px-5 py-2.5 text-sm font-semibold text-amber transition-all hover:bg-flame hover:text-ink sm:inline-flex"
          >
            مشاهدهٔ آگهی‌ها
          </Link>
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="grid h-11 w-11 place-items-center rounded-full border border-white/15 text-cream lg:hidden"
            aria-label="منو"
          >
            <span className="flex flex-col gap-1.5">
              <span className={`h-0.5 w-5 bg-current transition-transform ${open ? "translate-y-2 rotate-45" : ""}`} />
              <span className={`h-0.5 w-5 bg-current transition-opacity ${open ? "opacity-0" : ""}`} />
              <span className={`h-0.5 w-5 bg-current transition-transform ${open ? "-translate-y-2 -rotate-45" : ""}`} />
            </span>
          </button>
        </div>
      </div>

      {open && (
        <div className="mx-4 mt-3 rise-in rounded-3xl border border-white/10 bg-charcoal/95 p-4 backdrop-blur-xl lg:hidden">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="block rounded-2xl px-4 py-3 text-base text-cream/90 transition-colors hover:bg-white/5 hover:text-amber"
            >
              {item.label}
            </Link>
          ))}
          <Link
            href="/properties"
            onClick={() => setOpen(false)}
            className="mt-2 block rounded-2xl bg-flame px-4 py-3 text-center text-base font-semibold text-ink"
          >
            مشاهدهٔ آگهی‌ها
          </Link>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="relative overflow-hidden border-t border-white/10 bg-charcoal pt-16">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.14]"
        style={{
          backgroundImage: "url(/images/tehran-aerial.jpg)",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <div className="relative mx-auto grid max-w-7xl gap-10 px-5 pb-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo />
          <p className="mt-5 max-w-md text-sm leading-7 text-mist">
            دیمت هوم، پلتفرم تخصصی املاک لوکس منطقهٔ ۲ و ۳ تهران؛ از ونک و جردن تا سعادت‌آباد و شهرک غرب.
            تحلیل داده‌محور قیمت، مشاور هوشمند و تیم بازاریابیِ اختصاصی.
          </p>
          <div className="mt-6 flex flex-wrap gap-2 text-xs text-mist">
            {["ونک", "جردن", "میرداماد", "ظفر", "سعادت‌آباد", "شهرک غرب", "شیخ بهایی", "کامکارها"].map((n) => (
              <span key={n} className="rounded-full border border-white/10 bg-white/5 px-3 py-1">
                {n}
              </span>
            ))}
          </div>
        </div>
        <div>
          <h4 className="mb-4 text-sm font-bold text-cream">دسترسی سریع</h4>
          <ul className="space-y-3 text-sm text-mist">
            <li><Link className="hover:text-amber" href="/properties?deal=sale">فروش املاک</Link></li>
            <li><Link className="hover:text-amber" href="/properties?deal=rent">رهن و اجاره</Link></li>
            <li><Link className="hover:text-amber" href="/properties?category=office">املاک اداری</Link></li>
            <li><Link className="hover:text-amber" href="/properties?type=villa">ویلایی</Link></li>
            <li><Link className="hover:text-amber" href="/properties?type=old">کلنگی</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-sm font-bold text-cream">تماس</h4>
          <ul className="space-y-3 text-sm text-mist">
            <li>بلوار نلسون ماندلا، خیابان مریم، پلاک ۲۴</li>
            <li dir="ltr" className="text-amber">+98 21 2266 4400</li>
            <li dir="ltr" className="text-amber">+98 912 000 4400</li>
            <li>hello@demethome.ir</li>
            <li>شنبه تا پنجشنبه — ۹ تا ۲۱</li>
          </ul>
        </div>
      </div>
      <div className="relative border-t border-white/10 py-6 text-center text-xs text-mist">
        © ۱۴۰۴ Demet Home — تمامی حقوق محفوظ است. طراحی و توسعه با ♥ در تهران
      </div>
    </footer>
  );
}

export default SiteHeader;
