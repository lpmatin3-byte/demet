"use client";

import { useEffect, useState } from "react";

type Props = {
  src: string;
  fallback: string;
  alt: string;
  className?: string;
  loading?: "lazy" | "eager";
  style?: React.CSSProperties;
};

/** تصویر با جایگزین خودکار — اگر هاست بیرونی در دسترس نبود، تصویر ذخیره‌شده نمایش داده می‌شود. */
export default function SmartImage({ src, fallback, alt, className, loading = "lazy", style }: Props) {
  const [current, setCurrent] = useState(src);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setCurrent(src);
    setFailed(false);
  }, [src]);

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={failed ? fallback : current}
      alt={alt}
      loading={loading}
      decoding="async"
      referrerPolicy="no-referrer"
      className={className}
      style={style}
      onError={() => {
        if (!failed) setFailed(true);
        else setCurrent(fallback);
      }}
    />
  );
}
