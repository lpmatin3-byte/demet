"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import { formatPerM2, formatPriceShort, formatShortToman, toFa } from "@/lib/format";

export type MapNeighborhood = {
  slug: string;
  name: string;
  district: number;
  lat: number;
  lng: number;
  salePerM2: number;
  rentPerM2: number;
  depositPerM2: number;
  trendPct: number;
  yieldPct: number;
  tags: string[];
  tagline: string;
};

const LNG0 = 51.34;
const LNG1 = 51.475;
const LAT0 = 35.732;
const LAT1 = 35.80;

const toWorld = (lat: number, lng: number): [number, number] => [
  ((lng - LNG0) / (LNG1 - LNG0)) * 116 - 58,
  ((LAT1 - lat) / (LAT1 - LAT0)) * 116 - 58,
];

type Pt = { x: number; y: number; s: number; d: number };

/**
 * پروجکشن هوایی: دوربین بالای نقشه و در سمت جنوب قرار دارد؛
 * جنوب نزدیک‌تر (پایین صفحه) و شمال دورتر (بالای صفحه) است — مطابق نقشه‌های سه‌بعدی استاندارد.
 */
function project(x: number, z: number, h: number, yaw: number, pitch: number, dist: number): Pt {
  const cy = Math.cos(yaw);
  const sy = Math.sin(yaw);
  const X = x * cy - z * sy;
  const Z = x * sy + z * cy;
  const cp = Math.cos(pitch);
  const sp = Math.sin(pitch);
  const Y = h * cp - Z * sp;
  const D = -(Z * cp + h * sp);
  // پرسپکتیو ملایم (نزدیک ارتوگرافیک) تا نقشه به‌صورت هوایی و صاف دیده شود
  const f = dist / (dist + D / 160);
  return { x: X * f, y: -Y * f, s: f, d: D };
}

const ROADS: Array<{ name: string; pts: Array<[number, number]> }> = [
  {
    name: "خیابان ولیعصر",
    pts: [[35.7440, 51.4050], [35.7560, 51.4110], [35.7700, 51.4180], [35.7830, 51.4245], [35.7990, 51.4340]],
  },
  {
    name: "بزرگراه همت",
    pts: [[35.7555, 51.3300], [35.7560, 51.3900], [35.7555, 51.4450], [35.7545, 51.4800]],
  },
  {
    name: "بزرگراه حکیم",
    pts: [[35.7460, 51.3350], [35.7470, 51.4000], [35.7465, 51.4700]],
  },
  {
    name: "بلوار نلسون ماندلا",
    pts: [[35.7615, 51.4150], [35.7680, 51.4200], [35.7760, 51.4260]],
  },
  {
    name: "بلوار میرداماد",
    pts: [[35.7630, 51.4210], [35.7620, 51.4350], [35.7610, 51.4500]],
  },
  {
    name: "بزرگراه صدر",
    pts: [[35.7730, 51.4260], [35.7780, 51.4430], [35.7820, 51.4650]],
  },
  {
    name: "بزرگراه یادگار امام",
    pts: [[35.7820, 51.3400], [35.7830, 51.3900], [35.7840, 51.4300]],
  },
];

const BOUNDARY: Array<[number, number]> = [
  [35.7330, 51.3340], [35.7370, 51.3720], [35.7340, 51.4110], [35.7390, 51.4460],
  [35.7460, 51.4720], [35.7700, 51.4920], [35.7910, 51.4720], [35.7990, 51.4400],
  [35.7960, 51.4080], [35.7900, 51.3790], [35.7960, 51.3500], [35.7810, 51.3330],
];

export default function TehranMap3D({ items }: { items: MapNeighborhood[] }) {
  const router = useRouter();
  const [yaw, setYaw] = useState(-0.14);
  const [pitch, setPitch] = useState(1);
  const [zoom, setZoom] = useState(1.25);
  const [auto, setAuto] = useState(true);
  const [active, setActive] = useState<string>(items[0]?.slug ?? "");
  const drag = useRef<{ x: number; y: number; yaw: number; pitch: number } | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const raf = useRef(0);

  useEffect(() => {
    if (!auto) return;
    let start: number | null = null;
    let last = 0;
    let visible = true;
    const node = wrapRef.current;
    const io = new IntersectionObserver((entries) => {
      visible = entries[0]?.isIntersecting ?? true;
    }, { rootMargin: "120px" });
    if (node) io.observe(node);
    const loop = (ts: number) => {
      if (start === null) start = ts;
      // ۲۴ فریم بر ثانیه — سبک و بدون لگ
      if (visible && ts - last > 42) {
        last = ts;
        const t = (ts - start) / 1000;
        // حرکت نوسانی ملایم — شمال همیشه بالای نقشه می‌ماند
        setYaw(-0.14 + Math.sin(t * 0.3) * 0.38);
      }
      raf.current = requestAnimationFrame(loop);
    };
    raf.current = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf.current);
      io.disconnect();
    };
  }, [auto]);

  // کامکارها از نقشهٔ سه‌بعدی حذف شده است (خواهش کارفرما)
  const pins = useMemo(() => items.filter((i) => i.slug !== "kamkarha"), [items]);

  const priceRange = useMemo(() => {
    const values = pins.map((i) => i.salePerM2);
    return { min: Math.min(...values), max: Math.max(...values) };
  }, [items]);

  const heightOf = (price: number) => 8 + ((price - priceRange.min) / Math.max(1, priceRange.max - priceRange.min)) * 34;

  const geo = useMemo(() => {
    const dist = 3;
    const project2 = (lat: number, lng: number, h = 0) => {
      const [x, z] = toWorld(lat, lng);
      return project(x, z, h, yaw, pitch, dist);
    };

    // ground grid
    let grid = "";
    for (let i = -6; i <= 6; i += 1) {
      const u = i * 10;
      const a = project(u, -60, 0, yaw, pitch, dist);
      const b = project(u, 60, 0, yaw, pitch, dist);
      grid += `M${a.x.toFixed(2)},${a.y.toFixed(2)}L${b.x.toFixed(2)},${b.y.toFixed(2)}`;
      const c = project(-60, u, 0, yaw, pitch, dist);
      const d = project(60, u, 0, yaw, pitch, dist);
      grid += `M${c.x.toFixed(2)},${c.y.toFixed(2)}L${d.x.toFixed(2)},${d.y.toFixed(2)}`;
    }

    const boundary = BOUNDARY.map(([lat, lng]) => {
      const p = project2(lat, lng);
      return `${p.x.toFixed(2)},${p.y.toFixed(2)}`;
    }).join(" ");

    const roads = ROADS.map((road) => {
      const pts = road.pts.map(([lat, lng]) => project2(lat, lng));
      const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(2)},${p.y.toFixed(2)}`).join(" ");
      const label = pts[Math.floor(pts.length / 2)];
      return { name: road.name, path, label };
    });

    const markers = pins
      .map((item) => {
        const h = heightOf(item.salePerM2);
        const base = project2(item.lat, item.lng, 0);
        const top = project2(item.lat, item.lng, h);
        return { item, h, base, top };
      })
      .sort((a, b) => b.base.d - a.base.d);

    return { grid, boundary, roads, pins: markers };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [yaw, pitch, pins, priceRange.min, priceRange.max]);

  const activeItem = items.find((i) => i.slug === active) ?? items[0];

  return (
    <div className="grid gap-8 lg:grid-cols-[1.35fr_1fr]">
      <div
        ref={wrapRef}
        className="relative h-[520px] overflow-hidden rounded-[32px] border border-white/10 bg-[radial-gradient(120%_100%_at_50%_0%,rgba(249,115,22,0.16),transparent_55%),linear-gradient(180deg,#101013,#08080a)]"
        onPointerDown={(e) => {
          drag.current = { x: e.clientX, y: e.clientY, yaw, pitch };
          setAuto(false);
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (!drag.current) return;
          const dx = e.clientX - drag.current.x;
          const dy = e.clientY - drag.current.y;
          setYaw(drag.current.yaw - dx * 0.006);
          setPitch(Math.min(1.42, Math.max(0.55, drag.current.pitch + dy * 0.004)));
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
        onPointerLeave={() => {
          drag.current = null;
        }}
        style={{ cursor: "grab", touchAction: "none" }}
      >
        <svg
          viewBox="-100 -100 200 200"
          className="h-full w-full select-none"
          style={{ transform: `scale(${zoom})`, transformOrigin: "center" }}
        >
          <defs>
            <linearGradient id="district-fill" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#FBBF24" stopOpacity="0.20" />
              <stop offset="55%" stopColor="#F97316" stopOpacity="0.13" />
              <stop offset="100%" stopColor="#F7F0E6" stopOpacity="0.05" />
            </linearGradient>
            <linearGradient id="pillar-stroke" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#FBBF24" stopOpacity="0.95" />
              <stop offset="100%" stopColor="#F97316" stopOpacity="0.15" />
            </linearGradient>
            <filter id="pin-glow" x="-120%" y="-120%" width="340%" height="340%">
              <feGaussianBlur stdDeviation="2.4" result="b" />
              <feMerge>
                <feMergeNode in="b" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* floor grid */}
          <path d={geo.grid} stroke="#F7F0E6" strokeOpacity="0.07" strokeWidth="0.4" fill="none" />

          {/* district ground */}
          <polygon points={geo.boundary} fill="url(#district-fill)" stroke="#F97316" strokeOpacity="0.55" strokeWidth="0.6" />
          <polygon points={geo.boundary} fill="none" stroke="#FBBF24" strokeOpacity="0.28" strokeWidth="2.4" filter="url(#pin-glow)" />

          {/* roads */}
          {geo.roads.map((road) => (
            <g key={road.name}>
              <path d={road.path} stroke="#F7F0E6" strokeOpacity="0.16" strokeWidth="0.9" fill="none" strokeLinecap="round" />
              <text
                x={road.label.x}
                y={road.label.y - 1.6}
                fill="#9A9AA6"
                fontSize="2.5"
                textAnchor="middle"
                opacity="0.75"
              >
                {road.name}
              </text>
            </g>
          ))}

          {/* pillars */}
          {geo.pins.map(({ item, h, base, top }) => {
            const isActive = item.slug === active;
            return (
              <g
                key={item.slug}
                className="pin"
                onMouseEnter={() => setActive(item.slug)}
                onClick={() => {
                  setActive(item.slug);
                  router.push(`/properties?neighborhood=${item.slug}`);
                }}
              >
                <ellipse
                  cx={base.x}
                  cy={base.y}
                  rx={isActive ? 6 : 3.4}
                  ry={isActive ? 3.4 : 1.9}
                  fill={isActive ? "#F97316" : "#F7F0E6"}
                  opacity={isActive ? 0.35 : 0.14}
                />
                <line
                  x1={base.x}
                  y1={base.y}
                  x2={top.x}
                  y2={top.y}
                  stroke={isActive ? "#FBBF24" : "#9A9AA6"}
                  strokeWidth={isActive ? 1.5 : 0.7}
                  strokeOpacity={isActive ? 1 : 0.55}
                  className={isActive ? "dash-flow" : undefined}
                />
                <circle
                  cx={top.x}
                  cy={top.y}
                  r={(isActive ? 3.1 : 2.1) * top.s}
                  fill={isActive ? "#FBBF24" : "#F97316"}
                  filter="url(#pin-glow)"
                  className={isActive ? "spin-slow" : undefined}
                />
                {isActive && (
                  <circle cx={top.x} cy={top.y} r={7 * top.s} fill="none" stroke="#FBBF24" strokeWidth="0.5" opacity="0.7" className="pulse-ring" />
                )}
                <text
                  x={top.x + 4.5 * top.s}
                  y={top.y + 1}
                  fill={isActive ? "#F7F0E6" : "#9A9AA6"}
                  fontSize={isActive ? 4.2 : 3.2}
                  fontWeight={isActive ? 700 : 400}
                >
                  {item.name}
                </text>
                {isActive && (
                  <text x={top.x + 4.5 * top.s} y={top.y + 6} fill="#F97316" fontSize="3">
                    {formatPerM2(item.salePerM2)}
                  </text>
                )}
              </g>
            );
          })}

          {/* compass — north always readable */}
          {(() => {
            const sp = Math.sin(pitch);
            const cp = Math.cos(pitch);
            const sy = Math.sin(yaw);
            const cy = Math.cos(yaw);
            const dx = sy;
            const dy = -cy * sp;
            const len = Math.hypot(dx, dy) || 1;
            const ox = 74;
            const oy = -80;
            const nx = (dx / len) * 9;
            const ny = (dy / len) * 9;
            const px = -(dy / len) * 4.6;
            const py = (dx / len) * 4.6;
            return (
              <g>
                <circle cx={ox} cy={oy} r="10" fill="#14161b" fillOpacity="0.72" stroke="#a5abb6" strokeWidth="0.4" />
                <polygon
                  points={`${ox + nx},${oy + ny} ${ox + px},${oy + py} ${ox - nx * 0.45},${oy - ny * 0.45} ${ox - px},${oy - py}`}
                  fill="#e3bd85"
                />
                <text x={ox} y={oy + 16} fill="#a5abb6" fontSize="3.4" textAnchor="middle">
                  شمال
                </text>
              </g>
            );
          })()}

          {/* legend axis */}
          <g opacity="0.6">
            <line x1="62" y1="80" x2="86" y2="80" stroke="#F97316" strokeWidth="0.6" />
            <text x="62" y="86" fill="#9A9AA6" fontSize="3.4">
              ارتفاع ستون = قیمت هر متر
            </text>
          </g>
        </svg>

        {/* controls */}
        <div className="absolute bottom-4 left-4 flex items-center gap-2">
          <button
            type="button"
            onClick={() => setAuto((v) => !v)}
            className={`rounded-full border px-4 py-2 text-[0.68rem] font-bold backdrop-blur-md transition-colors ${
              auto ? "border-flame bg-flame text-ink" : "border-white/15 bg-ink/70 text-cream"
            }`}
          >
            {auto ? "توقف چرخش" : "چرخش خودکار"}
          </button>
          <button
            type="button"
            onClick={() => {
              setYaw(-0.14);
              setPitch(1);
              setZoom(1.25);
            }}
            className="rounded-full border border-white/15 bg-ink/70 px-4 py-2 text-[0.68rem] font-bold text-cream backdrop-blur-md"
          >
            بازنشانی نما
          </button>
          <button
            type="button"
            onClick={() => setYaw((v) => v - 0.25)}
            className="rounded-full border border-white/15 bg-ink/70 px-3 py-2 text-[0.68rem] font-bold text-cream backdrop-blur-md"
            aria-label="چرخش راست"
          >
            ⟲
          </button>
          <button
            type="button"
            onClick={() => setYaw((v) => v + 0.25)}
            className="rounded-full border border-white/15 bg-ink/70 px-3 py-2 text-[0.68rem] font-bold text-cream backdrop-blur-md"
            aria-label="چرخش چپ"
          >
            ⟳
          </button>
          <div className="hidden items-center gap-2 rounded-full border border-white/15 bg-ink/70 px-4 py-2 backdrop-blur-md sm:flex">
            <span className="text-[0.65rem] text-mist">بزرگ‌نمایی</span>
            <input
              type="range"
              min="0.9"
              max="1.9"
              step="0.05"
              value={zoom}
              onChange={(e) => setZoom(Number(e.target.value))}
              className="w-20 accent-flame"
            />
          </div>
        </div>
        <p className="pointer-events-none absolute right-4 top-4 rounded-full border border-white/10 bg-ink/70 px-4 py-2 text-[0.65rem] text-mist backdrop-blur-md">
          برای چرخش بکشید • با کلیک روی محله، فایل‌های همان محله باز می‌شود
        </p>
      </div>

      {/* selected neighbourhood panel */}
      <div className="flex flex-col gap-5">
        {activeItem && (
          <div key={activeItem.slug} className="rise-in glass rounded-[28px] p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="kicker">منطقه {toFa(activeItem.district)} تهران</p>
                <h3 className="display mt-3 text-3xl text-cream">{activeItem.name}</h3>
                <p className="mt-2 text-sm text-mist">{activeItem.tagline}</p>
              </div>
              <span className="rounded-2xl bg-flame/15 px-3 py-2 text-center">
                <span className="block text-[0.6rem] text-mist">روند سالانه</span>
                <span className="block text-sm font-extrabold text-amber">+{toFa(activeItem.trendPct)}٪</span>
              </span>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3">
              <div className="rounded-2xl border border-white/10 bg-ink/50 p-4">
                <p className="text-[0.65rem] text-mist">فروش هر متر</p>
                <p className="mt-1 text-base font-extrabold text-cream">{formatPerM2(activeItem.salePerM2)}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-ink/50 p-4">
                <p className="text-[0.65rem] text-mist">اجارهٔ ماهانهٔ هر متر</p>
                <p className="mt-1 text-base font-extrabold text-cream">
                  {formatShortToman(activeItem.rentPerM2)}
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-ink/50 p-4">
                <p className="text-[0.65rem] text-mist">رهن کامل هر متر</p>
                <p className="mt-1 text-base font-extrabold text-cream">{formatPriceShort(activeItem.depositPerM2)}</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-ink/50 p-4">
                <p className="text-[0.65rem] text-mist">بازده اجاره</p>
                <p className="mt-1 text-base font-extrabold text-cream">{toFa(activeItem.yieldPct.toFixed(1))}٪</p>
              </div>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              {activeItem.tags.map((t) => (
                <span key={t} className="rounded-full border border-flame/25 bg-flame/10 px-3 py-1 text-[0.65rem] text-amber">
                  {t}
                </span>
              ))}
            </div>

            <Link
              href={`/properties?neighborhood=${activeItem.slug}`}
              className="mt-6 block rounded-2xl bg-gradient-to-l from-gold via-flame to-copper py-3.5 text-center text-sm font-extrabold text-ink transition-transform hover:scale-[1.02]"
            >
              مشاهدهٔ آگهی‌های {activeItem.name}
            </Link>
          </div>
        )}

        <div className="no-scrollbar max-h-[240px] overflow-y-auto rounded-[24px] border border-white/10 bg-charcoal/60 p-3">
          <div className="grid grid-cols-2 gap-2">
            {items.map((i) => (
              <button
                key={i.slug}
                type="button"
                onMouseEnter={() => setActive(i.slug)}
                onClick={() => router.push(`/properties?neighborhood=${i.slug}`)}
                className={`rounded-2xl px-3 py-2.5 text-start transition-colors ${
                  i.slug === active ? "bg-flame text-ink" : "text-cream/80 hover:bg-white/5"
                }`}
              >
                <span className="block text-[0.75rem] font-bold">{i.name}</span>
                <span className={`block text-[0.62rem] ${i.slug === active ? "text-ink/70" : "text-mist"}`}>
                  {formatPerM2(i.salePerM2)}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
