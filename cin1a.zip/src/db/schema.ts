import {
  bigint,
  boolean,
  doublePrecision,
  integer,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const neighborhoods = pgTable("neighborhoods", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  nameEn: text("name_en").notNull(),
  district: integer("district").notNull(),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  heroImage: text("hero_image").notNull(),
  /** میانگین قیمت فروش هر متر مربع (تومان) */
  salePerM2: bigint("sale_per_m2", { mode: "number" }).notNull(),
  /** رهن کامل هر متر مربع (تومان) */
  depositPerM2: bigint("deposit_per_m2", { mode: "number" }).notNull(),
  /** اجاره ماهانه هر متر مربع (تومان) */
  rentPerM2: bigint("rent_per_m2", { mode: "number" }).notNull(),
  yieldPct: real("yield_pct").notNull(),
  trendPct: real("trend_pct").notNull(),
  tags: text("tags").array().notNull(),
});

export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  /** sale | rent */
  dealType: text("deal_type").notNull(),
  /** residential | office | commercial */
  category: text("category").notNull(),
  /** apartment | villa | mixed | old | shop */
  propertyType: text("property_type").notNull(),
  neighborhoodSlug: text("neighborhood_slug").notNull(),
  address: text("address").notNull(),
  areaM2: integer("area_m2").notNull(),
  rooms: integer("rooms").notNull(),
  bedrooms: integer("bedrooms").notNull(),
  bathrooms: integer("bathrooms").notNull(),
  floor: integer("floor").notNull().default(0),
  totalFloors: integer("total_floors").notNull().default(1),
  buildYear: integer("build_year").notNull(),
  price: bigint("price", { mode: "number" }),
  deposit: bigint("deposit", { mode: "number" }),
  rentMonthly: bigint("rent_monthly", { mode: "number" }),
  pricePerM2: bigint("price_per_m2", { mode: "number" }),
  hasParking: boolean("has_parking").notNull().default(false),
  hasElevator: boolean("has_elevator").notNull().default(false),
  hasBalcony: boolean("has_balcony").notNull().default(false),
  hasYard: boolean("has_yard").notNull().default(false),
  isRenovated: boolean("is_renovated").notNull().default(false),
  features: text("features").array().notNull(),
  description: text("description").notNull(),
  images: text("images").array().notNull(),
  isFeatured: boolean("is_featured").notNull().default(false),
  views: integer("views").notNull().default(0),
  source: text("source"),
  sourceUrl: text("source_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const buildings = pgTable("buildings", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  nameEn: text("name_en").notNull(),
  neighborhoodSlug: text("neighborhood_slug").notNull(),
  address: text("address").notNull(),
  builder: text("builder").notNull(),
  architect: text("architect").notNull(),
  style: text("style").notNull(),
  usage: text("usage").notNull(),
  yearBuilt: integer("year_built").notNull(),
  floors: text("floors").notNull(),
  units: text("units").notNull(),
  landArea: integer("land_area").notNull(),
  buildArea: integer("build_area").notNull(),
  unitSizes: text("unit_sizes").notNull(),
  salePerM2: bigint("sale_per_m2", { mode: "number" }).notNull(),
  priceFrom: bigint("price_from", { mode: "number" }).notNull(),
  rentDepositPerM2: bigint("rent_deposit_per_m2", { mode: "number" }).notNull(),
  rentPerM2: bigint("rent_per_m2", { mode: "number" }).notNull(),
  lat: doublePrecision("lat").notNull(),
  lng: doublePrecision("lng").notNull(),
  features: text("features").array().notNull(),
  nearby: text("nearby").array().notNull(),
  description: text("description").notNull(),
  images: text("images").array().notNull(),
  isFeatured: boolean("is_featured").notNull().default(false),
});

export type Building = typeof buildings.$inferSelect;

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  sessionId: text("session_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  intent: text("intent"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const inquiries = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  message: text("message"),
  propertyCode: text("property_code"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Neighborhood = typeof neighborhoods.$inferSelect;
export type Property = typeof properties.$inferSelect;
