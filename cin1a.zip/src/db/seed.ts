import { sql } from "drizzle-orm";
import { db } from "@/db";
import { buildings, neighborhoods, properties } from "@/db/schema";
import { BUILDINGS } from "@/lib/data/buildings";
import { REAL_LISTINGS } from "@/lib/data/real-media";
import { buildProperties, NEIGHBORHOODS } from "@/lib/data/seed-data";

const DATA_VERSION = "mehr-1405-r5";

const DDL = `
create table if not exists neighborhoods (
  id serial primary key,
  slug text not null unique,
  name text not null,
  name_en text not null,
  district integer not null,
  lat double precision not null,
  lng double precision not null,
  tagline text not null,
  description text not null,
  hero_image text not null,
  sale_per_m2 bigint not null,
  deposit_per_m2 bigint not null,
  rent_per_m2 bigint not null,
  yield_pct real not null,
  trend_pct real not null,
  tags text[] not null
);
create table if not exists properties (
  id serial primary key,
  code text not null unique,
  slug text not null unique,
  title text not null,
  deal_type text not null,
  category text not null,
  property_type text not null,
  neighborhood_slug text not null,
  address text not null,
  area_m2 integer not null,
  rooms integer not null,
  bedrooms integer not null,
  bathrooms integer not null,
  floor integer not null default 0,
  total_floors integer not null default 1,
  build_year integer not null,
  price bigint,
  deposit bigint,
  rent_monthly bigint,
  price_per_m2 bigint,
  has_parking boolean not null default false,
  has_elevator boolean not null default false,
  has_balcony boolean not null default false,
  has_yard boolean not null default false,
  is_renovated boolean not null default false,
  features text[] not null,
  description text not null,
  images text[] not null,
  is_featured boolean not null default false,
  views integer not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists buildings (
  id serial primary key,
  slug text not null unique,
  name text not null,
  name_en text not null,
  neighborhood_slug text not null,
  address text not null,
  builder text not null,
  architect text not null,
  style text not null,
  usage text not null,
  year_built integer not null,
  floors text not null,
  units text not null,
  land_area integer not null,
  build_area integer not null,
  unit_sizes text not null,
  sale_per_m2 bigint not null,
  price_from bigint not null,
  rent_deposit_per_m2 bigint not null,
  rent_per_m2 bigint not null,
  lat double precision not null,
  lng double precision not null,
  features text[] not null,
  nearby text[] not null,
  description text not null,
  images text[] not null,
  is_featured boolean not null default false
);
create table if not exists chat_messages (
  id serial primary key,
  session_id text not null,
  role text not null,
  content text not null,
  intent text,
  created_at timestamptz not null default now()
);
create table if not exists inquiries (
  id serial primary key,
  name text not null,
  phone text not null,
  message text,
  property_code text,
  created_at timestamptz not null default now()
);
create table if not exists seed_meta (
  key text primary key,
  value text not null
);
alter table properties add column if not exists source text;
alter table properties add column if not exists source_url text;
create index if not exists properties_deal_idx on properties (deal_type);
create index if not exists properties_nb_idx on properties (neighborhood_slug);
create index if not exists properties_type_idx on properties (property_type);
`;

let bootstrap: Promise<void> | null = null;

async function run() {
  await db.execute(sql.raw(DDL));

  const version = await db.execute<{ value: string }>(sql`select value from seed_meta where key = 'data_version'`);
  if (version.rows[0]?.value === DATA_VERSION) return;

  await db.execute(sql`truncate table properties, neighborhoods, buildings restart identity`);

  await db.insert(neighborhoods).values(
    NEIGHBORHOODS.map((n) => ({
      slug: n.slug,
      name: n.name,
      nameEn: n.nameEn,
      district: n.district,
      lat: n.lat,
      lng: n.lng,
      tagline: n.tagline,
      description: n.description,
      heroImage: n.heroImage,
      salePerM2: n.salePerM2,
      depositPerM2: n.depositPerM2,
      rentPerM2: n.rentPerM2,
      yieldPct: n.yieldPct,
      trendPct: n.trendPct,
      tags: n.tags,
    })),
  );

  const rows = buildProperties();
  for (let i = 0; i < rows.length; i += 40) {
    await db.insert(properties).values(rows.slice(i, i + 40));
  }

  await db.insert(buildings).values(
    BUILDINGS.map((b) => ({
      slug: b.slug,
      name: b.name,
      nameEn: b.nameEn,
      neighborhoodSlug: b.neighborhoodSlug,
      address: b.address,
      builder: b.builder,
      architect: b.architect,
      style: b.style,
      usage: b.usage,
      yearBuilt: b.yearBuilt,
      floors: b.floors,
      units: b.units,
      landArea: b.landArea,
      buildArea: b.buildArea,
      unitSizes: b.unitSizes,
      salePerM2: b.salePerM2,
      priceFrom: b.priceFrom,
      rentDepositPerM2: b.rentDepositPerM2,
      rentPerM2: b.rentPerM2,
      lat: b.lat,
      lng: b.lng,
      features: b.features,
      nearby: b.nearby,
      description: b.description,
      images: b.images,
      isFeatured: b.isFeatured,
    })),
  );

  // آگهی‌های واقعی استخراج‌شده از پورتال‌های ایرانی
  const realRows = REAL_LISTINGS.map((r, i) => ({
    code: `DH-R${100 + i}`,
    slug: `real-${r.neighborhoodSlug}-${r.areaM2}-${100 + i}`,
    title: r.title,
    dealType: r.dealType,
    category: r.category,
    propertyType: r.propertyType,
    neighborhoodSlug: r.neighborhoodSlug,
    address: r.address,
    areaM2: r.areaM2,
    rooms: r.bedrooms + 1,
    bedrooms: r.bedrooms,
    bathrooms: 1 + Math.floor(r.areaM2 / 90),
    floor: r.floor,
    totalFloors: r.totalFloors,
    buildYear: r.buildYear,
    price: r.price ?? null,
    deposit: r.deposit ?? null,
    rentMonthly: r.rentMonthly ?? (r.deposit ? 0 : null),
    pricePerM2: r.price ? Math.round(r.price / r.areaM2) : null,
    hasParking: true,
    hasElevator: true,
    hasBalcony: r.areaM2 > 100,
    hasYard: r.propertyType === "villa",
    isRenovated: r.buildYear >= 1400,
    features: [`منبع: ${r.source}`, "آگهی واقعی", "قیمت ثبت‌شدهٔ مهر ۱۴۰۵"],
    description: `این آگهی از پورتال «${r.source}» استخراج شده و قیمت آن در مهر ۱۴۰۵ ثبت شده است. برای مشاهدهٔ نسخهٔ اصلی آگهی روی لینک منبع کلیک کنید.`,
    images: r.images,
    isFeatured: i < 8,
    views: 120 + i * 17,
    source: r.source,
    sourceUrl: r.sourceUrl,
  }));
  await db.insert(properties).values(realRows);

  await db.execute(
    sql`insert into seed_meta (key, value) values ('data_version', ${DATA_VERSION})
        on conflict (key) do update set value = excluded.value`,
  );
}

export function ensureSeeded(): Promise<void> {
  if (!bootstrap) {
    bootstrap = run().catch((error) => {
      bootstrap = null;
      throw error;
    });
  }
  return bootstrap;
}
