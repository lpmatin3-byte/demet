import { BUILDINGS } from "@/lib/data/buildings";
import { NEIGHBORHOODS } from "@/lib/data/seed-data";
import { findStreetTier } from "@/lib/data/streets";
import { NEARBY, POI_TYPE_ICON } from "@/lib/data/real-media";
import { formatPerM2, formatPriceShort, formatShortToman, toFa } from "@/lib/format";
import { CURRENT_YEAR, valueUnit } from "@/lib/pricing";
import { getBuildings, getProperties } from "@/lib/queries";
import { findLegalAnswer, LEGAL_TOPICS } from "./legal";

export type ChatCard = {
  title: string;
  subtitle: string;
  href: string;
  image: string;
  badge: string;
};

export type ChatResult = {
  intent: string;
  reply: string;
  cards: ChatCard[];
  chips: string[];
  sources: string[];
};

const FA_MAP: Record<string, string> = {
  "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4", "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
  "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
  "ي": "ی", "ك": "ک", "ۀ": "ه", "أ": "ا", "إ": "ا", "آ": "ا", "ة": "ه", "‌": " ",
};

const WORD_NUMBERS: Record<string, number> = {
  یک: 1, دو: 2, سه: 3, چهار: 4, پنج: 5, شش: 6, هفت: 7, هشت: 8, نه: 9, ده: 10,
  یازده: 11, دوازده: 12, سی: 30, چهل: 40, پنجاه: 50, صد: 100, دویست: 200,
};

const TYPE_WORDS: Array<[RegExp, string]> = [
  [/اپارتمان|آپارتمان|اپارت|واحد مسکونی|واحد|خونه|خانه|خانه‌ای/, "apartment"],
  [/ویلایی|ویلا|دوبلکس|تراس خاک‌ریز/, "villa"],
  [/کلنگی|بازسازی|خرابه|مشارکت در ساخت|مدفون/, "old"],
  [/اداری|دفتر کار|دفتر|شرکت|اتاق کار|سوییت/, "office"],
  [/مستغلات|مستقل/, "mixed"],
  [/مغازه|غرفه|بوتیک|سرقفلی/, "shop"],
];

const BUILDING_ALIASES: Array<{ slug: string; keys: string[] }> = [
  { slug: "pars-tower-jordan", keys: ["برج پارس", "پارس جردن", "بیمه مرکزی", "pars tower"] },
  { slug: "helios-tower", keys: ["هلیوس", "helios"] },
  { slug: "future-complex", keys: ["برج فیوچر", "فیوچر", "future"] },
  { slug: "side-park-nexa", keys: ["ساید پارک", "سایدپارک", "side park"] },
  { slug: "xima-nexa", keys: ["زیما", "xima"] },
  { slug: "sedrous-nexa", keys: ["سدروس", "sedrous"] },
  { slug: "pixel-nexa", keys: ["پیکسل", "pixel"] },
  { slug: "ando-nexa", keys: ["آندو", "اندو", "ando"] },
  { slug: "rythme-villa", keys: ["ریتم", "rythme"] },
  { slug: "eleven-villa-zaferanieh", keys: ["الون وایلا", "eleven villa"] },
  { slug: "grando-nexa", keys: ["گراندو", "grando"] },
  { slug: "hermozan-tower", keys: ["هرمزان", "hermozan"] },
  { slug: "artiman-zaferanieh", keys: ["برج آرتمان", "آرتمان زعفرانیه", "artiman"] },
  { slug: "parsiyan-towers", keys: ["برج های پارسیان", "برج‌های پارسیان", "برج پارسیان", "پارسیان ونک"] },
  { slug: "parsian-insurance-building", keys: ["بیمه پارسیان"] },
  { slug: "mezzo-nexa", keys: ["مزو", "مِزو", "mezzo"] },
  { slug: "lumen-nexa", keys: ["لومن", "lumen"] },
  { slug: "nexous-nexa", keys: ["نکسوس", "nexous"] },
];

const NEXA_KEYS = ["نکسا", "نکسا گروپ", "nexa"];

function normalize(input: string): string {
  return input
    .replace(/[۰-۹٠-٩يكةأإآۀ]/g, (c) => FA_MAP[c] ?? c)
    .replace(/\u200c/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

export type ParsedQuery = {
  neighborhoodSlug: string | null;
  neighborhoodName: string | null;
  alsoMentioned: string[];
  area: number | null;
  bedrooms: number | null;
  dealType: "sale" | "rent" | null;
  propertyType: string | null;
  budget: number | null;
  direction: "north" | "south" | null;
  buildYear: number | null;
  ageYears: number | null;
  street: string | null;
  buildingSlug: string | null;
  isNexa: boolean;
};

function parseMoney(text: string): number | null {
  const bn = text.match(/(\d+(?:[.,]\d+)?)\s*(میلیارد|ملیارد|بیلیون)/);
  if (bn) return Math.round(parseFloat(bn[1].replace(",", ".")) * 1_000_000_000);
  const mn = text.match(/(\d+(?:[.,]\d+)?)\s*(میلیون|ملیون)/);
  if (mn) return Math.round(parseFloat(mn[1].replace(",", ".")) * 1_000_000);
  const tm = text.match(/(\d{8,})\s*(تومان|تومن)?/);
  if (tm) return Number(tm[1]);
  return null;
}

export function parseQuery(raw: string): ParsedQuery {
  const t = normalize(raw);

  let area: number | null = null;
  const areaMatch = t.match(/(\d{2,4})\s*(متراژ|متری|متر مربع|متر)/);
  if (areaMatch) area = Number(areaMatch[1]);
  if (!area) {
    const wordArea = t.match(new RegExp(`(${Object.keys(WORD_NUMBERS).join("|")})\\s*(متری|متراژ|متر)`));
    if (wordArea) area = WORD_NUMBERS[wordArea[1]];
  }

  let bedrooms: number | null = null;
  const bedMatch = t.match(/(\d)\s*خواب/);
  if (bedMatch) bedrooms = Number(bedMatch[1]);
  if (bedrooms === null) {
    const wordBed = t.match(new RegExp(`(${Object.keys(WORD_NUMBERS).join("|")})\\s*خواب`));
    if (wordBed) bedrooms = WORD_NUMBERS[wordBed[1]];
  }

  let dealType: "sale" | "rent" | null = null;
  if (/رهن|اجاره|مستاجر|اجاره‌ای|کرایه/.test(t)) dealType = "rent";
  if (/خرید|بخرم|فروش|بفروشم|قیمت خرید/.test(t)) dealType = "sale";

  let propertyType: string | null = null;
  for (const [re, type] of TYPE_WORDS) {
    if (re.test(t)) {
      propertyType = type;
      break;
    }
  }

  let buildYear: number | null = null;
  const yearMatch = t.match(/(?:سال ساخت\s*)?(1[234]\d{2})/);
  if (yearMatch) {
    const y = Number(yearMatch[1]);
    if (y >= 1370 && y <= CURRENT_YEAR + 3) buildYear = y;
  }
  let ageYears: number | null = null;
  const ageMatch = t.match(/(\d{1,2})\s*ساله/);
  if (ageMatch) ageYears = Number(ageMatch[1]);
  if (/نوساز|کلید نخورده|تازه ساخت|کلیدخورده/.test(t)) {
    buildYear = CURRENT_YEAR;
    ageYears = 0;
  }

  const matches = NEIGHBORHOODS.map((nb) => {
    let bestLen = 0;
    for (const alias of nb.aliases) {
      const a = normalize(alias);
      if (t.includes(a) && a.length > bestLen) bestLen = a.length;
    }
    return { nb, len: bestLen };
  })
    .filter((m) => m.len > 0)
    .sort((a, b) => b.len - a.len);

  const direction = /شمال|بالای|بالاتر/.test(t) ? "north" : /جنوب|پایین|پایین‌تر/.test(t) ? "south" : null;

  const tier = findStreetTier(raw);

  let buildingSlug: string | null = null;
  for (const entry of BUILDING_ALIASES) {
    const hit = entry.keys.some((k) => {
      const key = normalize(k).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      return new RegExp(`(^|[^\\p{L}])${key}([^\\p{L}]|$)`, "u").test(t);
    });
    if (hit) {
      buildingSlug = entry.slug;
      break;
    }
  }

  return {
    neighborhoodSlug: matches[0]?.nb.slug ?? null,
    neighborhoodName: matches[0]?.nb.name ?? null,
    alsoMentioned: matches.slice(1, 3).map((m) => m.nb.name),
    area,
    bedrooms,
    dealType,
    propertyType,
    budget: parseMoney(t),
    direction,
    buildYear,
    ageYears,
    street: tier?.street ?? null,
    buildingSlug,
    isNexa: NEXA_KEYS.some((k) => t.includes(normalize(k))),
  };
}

function areaFromBedrooms(bedrooms: number): number {
  if (bedrooms <= 1) return 70;
  if (bedrooms === 2) return 100;
  if (bedrooms === 3) return 145;
  if (bedrooms === 4) return 210;
  return 280;
}

function money(n: number | null | undefined) {
  return formatPriceShort(n ?? null);
}

/** تلاش برای بررسی لحظه‌ای بازار در دیوار (در صورت دسترسی شبکه). */
async function searchDivar(p: ParsedQuery, area: number | null) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 3500);
  try {
    const body = {
      city_ids: ["3"],
      source_view: "CATEGORY",
      search_data: {
        form_data: {
          data: {
            category: { str: { value: p.dealType === "rent" ? "rent-apartment" : "buy-apartment" } },
            neighborhood: { str_array: { value: [p.neighborhoodSlug ?? ""] } },
            size: { number_range: { minimum: Math.max(20, (area ?? 100) - 20), maximum: (area ?? 100) + 20 } },
          },
        },
      },
    };
    const res = await fetch("https://api.divar.ir/v8/postlist/w/search", {
      method: "POST",
      headers: { "content-type": "application/json", "user-agent": "Mozilla/5.0" },
      body: JSON.stringify(body),
      signal: controller.signal,
      cache: "no-store",
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { web_widgets?: { post_list?: unknown[] } };
    const list = json?.web_widgets?.post_list;
    if (!Array.isArray(list)) return null;
    return { count: list.length };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function buildingAnswer(slug: string) {
  const b = BUILDINGS.find((x) => x.slug === slug);
  if (!b) return null;
  const lines = [
    `### ${b.name} (${b.nameEn})`,
    "",
    `• محله: **${NEIGHBORHOODS.find((n) => n.slug === b.neighborhoodSlug)?.name ?? "—"}**`,
    `• آدرس: ${b.address}`,
    `• سازنده: **${b.builder}**`,
    `• معمار: ${b.architect}`,
    `• سبک: ${b.style}`,
    `• سال ساخت: ${toFa(b.yearBuilt)} • طبقات: ${b.floors}`,
    `• تعداد واحد: ${b.units} • متراژ واحدها: ${b.unitSizes}`,
    `• زمین: ${toFa(b.landArea)} متر • زیربنا: ${toFa(b.buildArea)} متر`,
    "",
    "### قیمت (مهر ۱۴۰۵)",
    `• فروش هر متر: **${formatPerM2(b.salePerM2)}**`,
    `• شروع قیمت واحد: **${money(b.priceFrom)}**`,
  ];
  if (b.rentPerM2 > 0) {
    lines.push(
      `• رهن کامل هر متر: ${formatPriceShort(b.rentDepositPerM2)}`,
      `• اجارهٔ ماهانهٔ هر متر: ${formatShortToman(b.rentPerM2)}`,
      `• نمونه: واحد ${toFa(180)} متری → رهن ${money(b.rentDepositPerM2 * 180)} + اجاره ${money(b.rentPerM2 * 180)}`,
    );
  } else {
    lines.push("• این پروژه در مرحلهٔ پیش‌فروش است و رهن و اجاره ندارد.");
  }
  lines.push("", "### امکانات", ...b.features.map((f) => `• ${f}`));
  lines.push("", "### دسترسی‌های اطراف", ...b.nearby.map((f) => `• ${f}`));
  lines.push("", b.description);
  return {
    intent: "building",
    reply: lines.join("\n"),
    cards: [
      {
        title: b.name,
        subtitle: `${b.builder} • ${formatPerM2(b.salePerM2)}`,
        href: `/buildings/${b.slug}`,
        image: b.images[0],
        badge: b.nameEn,
      },
    ],
    chips: [
      `قیمت آپارتمان ۱۲۰ متری در ${NEIGHBORHOODS.find((n) => n.slug === b.neighborhoodSlug)?.name}`,
      `پروژه‌های نکسا گروپ`,
      `قوانین پیش‌فروش را توضیح بده`,
    ],
    sources: ["Demet Home — پایگاه پروژه‌های برند"],
  } satisfies ChatResult;
}

function greetingReply(): ChatResult {
  return {
    intent: "greeting",
    reply:
      "سلام 👋 من **دیمت‌آی‌آی** هستم؛ مشاور هوشمند املاک Demet Home برای منطقهٔ ۲ و ۳ تهران.\n\nمی‌توانم:\n• قیمت دقیق هر ملک را با فرمول هدونیک (محله + خیابان + متراژ + سال ساخت + طبقه) برآورد کنم\n• رهن و اجاره را در سه سناریو حساب کنم\n• مشخصات برج‌های برند (پارس، هلیوس، فیوچر، ساید پارک، نکسا و…) را بدهم\n• سؤالات حقوقی ملکی را پاسخ بدهم\n\n### مثال\n• یک آپارتمان دو خوابه ۱۰۰ متری، سال ساخت ۱۳۹۵، در خیابان کامکارها — رهن و اجاره‌اش چقدر می‌شود؟",
    cards: [],
    chips: [
      "رهن و اجاره ۲ خوابه ۱۰۰ متری کامکارها",
      "برج پارس جردن رو معرفی کن",
      "قیمت آپارتمان ۱۲۰ متری نوساز در جردن",
      "قوانین قرارداد اجاره",
    ],
    sources: [],
  };
}

export async function answerQuestion(raw: string): Promise<ChatResult> {
  const text = raw.trim();
  if (!text) return greetingReply();

  const t = normalize(text);

  if (/^(سلام|درود|هی|hi|hello)/.test(t) && text.length < 24) return greetingReply();
  if (/(ممنون|مرسی|متشکر|دستت درد نکنه)/.test(t) && text.length < 30) {
    return {
      intent: "thanks",
      reply: "خوشحالم که کمک کردم 🙌 هر سؤال دیگری دربارهٔ محله‌ها، قیمت، برج‌های برند یا مسائل حقوقی داشتید همین‌جا بپرسید.",
      cards: [],
      chips: ["پروژه‌های نکسا گروپ", "بهترین محله برای سرمایه‌گذاری"],
      sources: [],
    };
  }

  const legal = legalReply(text);
  if (legal) return legal;

  const p = parseQuery(text);

  if (p.buildingSlug) {
    const answer = buildingAnswer(p.buildingSlug);
    if (answer) return answer;
  }

  if (p.isNexa) {
    const list = BUILDINGS.filter((b) => b.builder.includes("نکسا"));
    return {
      intent: "builder",
      reply:
        "### پروژه‌های گروه ساختمانی نکسا\n" +
        list
          .map(
            (b) =>
              `• **${b.name}** — ${NEIGHBORHOODS.find((n) => n.slug === b.neighborhoodSlug)?.name} • ${toFa(b.yearBuilt)} • ${b.unitSizes} • هر متر ${formatPerM2(b.salePerM2)}`,
          )
          .join("\n") +
        "\n\nگروه نکسا از سال ۱۳۸۷ به‌عنوان کارفرمای پروژه‌های لوکس در سعادت‌آباد، شهرک غرب و پاسداران فعالیت می‌کند؛ مجریِ پروژه‌ها شرکت نکستک است.",
      cards: list.slice(0, 4).map((b) => ({
        title: b.name,
        subtitle: `${formatPerM2(b.salePerM2)} • ${toFa(b.yearBuilt)}`,
        href: `/buildings/${b.slug}`,
        image: b.images[0],
        badge: b.nameEn,
      })),
      chips: list.slice(0, 4).map((b) => `${b.name} رو معرفی کن`),
      sources: ["nexagroup.net", "Demet Home"],
    };
  }

  if (!p.neighborhoodSlug) {
    if (/بهترین محله|سرمایه|بازده|اجاره‌دادن|سود/.test(t)) {
      const top = [...NEIGHBORHOODS].sort((a, b) => b.yieldPct - a.yieldPct).slice(0, 5);
      return {
        intent: "market",
        reply:
          "### بهترین محله‌ها برای سرمایه‌گذاری اجاره‌ای (مهر ۱۴۰۵)\n\n" +
          top
            .map(
              (n) =>
                `• **${n.name}** — بازده سالانهٔ ${toFa(n.yieldPct.toFixed(1))}٪ • هر متر ${formatPerM2(n.salePerM2)} • اجارهٔ ماهانهٔ هر متر ${formatShortToman(n.rentPerM2)} • روند سالانه +${toFa(n.trendPct)}٪`,
            )
            .join("\n") +
          "\n\nاگر متراژ، سال ساخت و خیابان را بگویید، با فرمول دقیق‌تر محاسبه می‌کنم.",
        cards: [],
        chips: top.map((n) => `قیمت آپارتمان ۱۰۰ متری ${n.name}`),
        sources: ["پایگاه دادهٔ Demet Home"],
      };
    }

    const featured = await getProperties({ limit: 4, featured: true });
    return {
      intent: "clarify",
      reply:
        "برای برآورد دقیق، **محله** یا **نام برج** را مشخص کنید. محله‌های تحت پوشش Demet Home:\n\n" +
        NEIGHBORHOODS.map((n) => `• ${n.name} (منطقه ${toFa(n.district)}) — هر متر ${formatPerM2(n.salePerM2)}`).join("\n") +
        "\n\n### مثال درست\n«آپارتمان ۲ خوابه ۱۰۰ متری، ساخت ۱۳۹۵، در خیابان کامکارها — رهن و اجاره‌اش چقدر می‌شود؟»",
      cards: featured.slice(0, 3).map((c) => ({
        title: c.title,
        subtitle: c.dealType === "sale" ? formatPriceShort(c.price) : `رهن ${formatPriceShort(c.deposit)} / اجاره ${formatPriceShort(c.rentMonthly)}`,
        href: `/properties/${c.slug}`,
        image: c.images[0],
        badge: c.code,
      })),
      chips: ["برج پارس جردن رو معرفی کن", "قیمت آپارتمان ۱۲۰ متری جردن", "پروژه‌های نکسا گروپ"],
      sources: [],
    };
  }

  const type = p.propertyType ?? "apartment";
  const area = p.area ?? (p.bedrooms ? areaFromBedrooms(p.bedrooms) : 100);
  const buildYear = p.buildYear ?? (p.ageYears ? CURRENT_YEAR - p.ageYears : null);

  const valuation = valueUnit({
    neighborhoodSlug: p.neighborhoodSlug,
    street: p.street ?? p.neighborhoodName,
    propertyType: type,
    areaM2: area,
    buildYear,
    ageYears: p.ageYears,
    orientation: p.direction ?? undefined,
  });
  if (!valuation) return greetingReply();

  const deal = p.dealType ?? "rent";

  let comps = await getProperties({
    neighborhood: p.neighborhoodSlug,
    deal,
    type,
    minArea: Math.max(20, area - 35),
    maxArea: area + 50,
    limit: 6,
  });
  if (comps.length === 0) comps = await getProperties({ neighborhood: p.neighborhoodSlug, limit: 6 });

  const divar = await searchDivar(p, area);
  const nb = NEIGHBORHOODS.find((n) => n.slug === p.neighborhoodSlug)!;
  const branded = await getBuildings(p.neighborhoodSlug);

  const lines: string[] = [];
  lines.push(
    `برآورد **${valuation.typeLabel} ${toFa(area)} متری**${p.bedrooms ? ` (${toFa(p.bedrooms ?? 0)} خوابه)` : ""} در **${valuation.neighborhood}**${
      p.street ? `، ${p.street}` : ""
    }${valuation.buildYear ? `، ساخت ${toFa(valuation.buildYear)}` : ""} — مهر ۱۴۰۵:`,
    "",
    `• قیمت هر متر: **${formatPerM2(valuation.perM2)}**`,
    `• ارزش کل واحد: **${money(valuation.total)}**`,
    `• بازهٔ واقعی معامله: **${money(valuation.low)} تا ${money(valuation.high)}**`,
    `• رهن کامل: **${money(valuation.rent.fullDeposit)}** • اجارهٔ کامل ماهانه: **${money(valuation.rent.fullRent)}**`,
    "",
    "### فرمول محاسبه (مدل هدونیک)",
  );
  valuation.factors.forEach((f) => {
    lines.push(`• ${f.label}: **${f.value}** — ${f.note}`);
  });
  lines.push("", "### سناریوهای رهن و اجاره");
  valuation.rent.scenarios.forEach((s) => {
    lines.push(`• ${s.label}: رهن **${money(s.deposit)}**${s.rent ? ` + اجارهٔ ماهانه **${money(s.rent)}**` : " (بدون اجاره)"}`);
  });

  if (comps.length) {
    const perMs = comps.map((c) => c.pricePerM2 ?? 0).filter(Boolean);
    lines.push("", "### آگهی‌های مشابه فعال");
    comps.slice(0, 3).forEach((c) => {
      const val =
        c.dealType === "sale"
          ? `${money(c.price)} (${formatPerM2(c.pricePerM2 ?? 0)})`
          : `رهن ${money(c.deposit)} / اجاره ${money(c.rentMonthly)}`;
      lines.push(`• ${c.title} — ${val}`);
    });
    if (perMs.length) {
      lines.push(`• میانگین واقعی این آگهی‌ها: **${formatPerM2(Math.round(perMs.reduce((a, b) => a + b, 0) / perMs.length))}**`);
    }
  }

  if (branded.length) {
    lines.push("", "### برج‌های برند این محله");
    branded.slice(0, 3).forEach((b) => {
      lines.push(`• **${b.name}** — ${b.builder.split("—")[0].trim()} • هر متر ${formatPerM2(b.salePerM2)}`);
    });
  }

  if (p.alsoMentioned.length) {
    lines.push("", `برای مقایسه: در ${p.alsoMentioned.join(" و ")} همین متراژ حدوداً ${formatPerM2(Math.round(valuation.perM2 * 0.85))} تا ${formatPerM2(Math.round(valuation.perM2 * 1.15))} است.`);
  }

  const pois = NEARBY[p.neighborhoodSlug] ?? [];
  if (pois.length) {
    lines.push("", "### موقعیت و دسترسی‌های نزدیک");
    pois.slice(0, 4).forEach((poi) => {
      lines.push(`• ${POI_TYPE_ICON[poi.type]} ${poi.name} — ${toFa(poi.minutes)} دقیقه`);
    });
  }

  lines.push(
    "",
    `**چکیدهٔ ${nb.name}:** ${nb.tagline} • روند سالانه +${toFa(nb.trendPct)}٪ • بازده اجاره ${toFa(nb.yieldPct.toFixed(1))}٪`,
    "",
    divar
      ? `منابع: فرمول هدونیک Demet Home + پایگاه دادهٔ داخلی + بررسی زندهٔ دیوار (${toFa(divar.count)} آگهی منطبق).`
      : "منابع: فرمول هدونیک Demet Home + پایگاه دادهٔ داخلی (به‌روزرسانی مهر ۱۴۰۵).",
  );

  const cards: ChatCard[] = [
    ...comps.slice(0, 3).map((c) => ({
      title: c.title,
      subtitle:
        c.dealType === "sale"
          ? `${money(c.price)} • ${formatPerM2(c.pricePerM2 ?? 0)}`
          : `رهن ${money(c.deposit)} / اجاره ${money(c.rentMonthly)}`,
      href: `/properties/${c.slug}`,
      image: c.images[0],
      badge: c.code,
    })),
    ...branded.slice(0, 2).map((b) => ({
      title: b.name,
      subtitle: `${formatPerM2(b.salePerM2)} • ${toFa(b.yearBuilt)}`,
      href: `/buildings/${b.slug}`,
      image: b.images[0],
      badge: b.nameEn,
    })),
  ];

  return {
    intent: "estimate",
    reply: lines.join("\n"),
    cards,
    chips: [
      `برج‌های برند ${nb.name}`,
      `قیمت خرید ${toFa(area)} متری نوساز در ${nb.name}`,
      "قوانین قرارداد اجاره را بگو",
      "بهترین محله برای سرمایه‌گذاری",
    ],
    sources: divar ? ["Demet Home", "Divar"] : ["Demet Home"],
  };
}

function legalReply(raw: string): ChatResult | null {
  const entry = findLegalAnswer(raw);
  if (!entry) return null;
  if (!/قانون|حقوق|ماده|تخلیه|کمیسیون|سند|مقررات|وکالت|مالیات|جریمه|سرقفلی|پیش‌فروش|پیش فروش|ودیعه/.test(normalize(raw))) {
    return null;
  }
  const others = LEGAL_TOPICS.filter((tl) => tl.id !== entry.id).slice(0, 4).map((tl) => tl.title);
  return {
    intent: "legal",
    reply: `### ${entry.title}\n\n${entry.body}\n\nمنبع: ${entry.source}\n\nاگر بخواهید می‌توانم دربارهٔ ${others
      .slice(0, 3)
      .join("، ")} هم توضیح بدهم.`,
    cards: [],
    chips: others,
    sources: [entry.source],
  };
}
