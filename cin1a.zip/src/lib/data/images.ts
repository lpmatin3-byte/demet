/** Image catalogue — curated luxury architecture & interior photography. */

const px = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1280`;

export const IMG = {
  villaDusk: px(24805054),
  villaPool: px(24807125),
  villaGarden: px(28054874),
  villaNight: px(19075398),
  villaTropical: px(28915352),
  villaTwilight: px(30781823),
  villaStone: px(19075389),
  villaInfinity: px(28054849),
  villaDeck: px(19075392),
  villaSunset: px(31817157),

  livingBlue: px(8082243),
  livingChandelier: px(8135492),
  livingTv: px(7174113),
  livingMinimal: px(7546323),
  livingSoft: px(34538288),
  livingOpen: px(8089172),
  livingBright: px(8082242),
  livingRug: px(6980661),
  livingLoft: px(7167073),
  livingPlan: px(8135496),

  facadePalm: px(2771935),
  facadeGeo: px(18506889),
  facadeBalcony: px(14294074),
  facadeClassic: px(13950257),
  facadeTower: px(3071587),
  facadeGlass: px(14989324),
  facadeModern: px(37334932),
  facadeWhite: px(3836508),
  facadeWorm: px(209218),
  facadeIzmir: px(27459248),

  terraceEvening: px(7045918),
  terraceFire: px(19923727),
  cityNight: px(33622135),
  terraceCity: px(9584741),
  cityDark: px(14508487),
  skyline: px(18824805),
  dubaiSkyline: px(1497417),
  astana: px(18549956),

  officeGlass: px(14408745),
  officeLobby: px(36286291),
  officeBright: px(5511099),
  officeOpen: px(5511098),
  officeStools: px(1504236),
  officeBoard: px(5444180),
  officeCorridor: px(7511755),
  officeMeeting: px(5511303),

  shopBeauty: px(13068364),
  shopMakeup: px(13068365),
  shopJewel: px(33257665),
  shopShelf: px(13068378),
  shopBoutique: px(8311885),
  shopRack: px(8386643),
  shopFashion: px(35045844),
  shopJewel2: px(33257668),

  kitchenMarble: px(7031879),
  kitchenLight: px(6587896),
  kitchenGray: px(6903155),
  kitchenModern: px(6987727),
  kitchenWhite: px(6538939),
  kitchenTable: px(6980655),
  kitchenTiles: px(8146212),

  tehranMilad: px(9153155),
  tehranAerial: px(31262146),
  tehranHelipad: px(3799047),
  tehranSunset: px(7449632),
  tehranMono: px(5510792),
  tehranAzadi: px(12618167),
  tehranDusk: px(31468386),
} as const;

export const VILLA_SHOTS = [
  IMG.villaDusk,
  IMG.villaPool,
  IMG.villaGarden,
  IMG.villaNight,
  IMG.villaTwilight,
  IMG.villaStone,
  IMG.villaInfinity,
  IMG.villaSunset,
];

export const INTERIOR_SHOTS = [
  IMG.livingChandelier,
  IMG.livingMinimal,
  IMG.livingOpen,
  IMG.livingSoft,
  IMG.livingBright,
  IMG.livingLoft,
  IMG.kitchenMarble,
  IMG.kitchenLight,
  IMG.kitchenTiles,
  IMG.livingPlan,
];

export const FACADE_SHOTS = [
  IMG.facadePalm,
  IMG.facadeGeo,
  IMG.facadeBalcony,
  IMG.facadeTower,
  IMG.facadeGlass,
  IMG.facadeModern,
  IMG.facadeWhite,
  IMG.facadeWorm,
  IMG.facadeIzmir,
];

export const OFFICE_SHOTS = [
  IMG.officeGlass,
  IMG.officeLobby,
  IMG.officeBright,
  IMG.officeOpen,
  IMG.officeBoard,
  IMG.officeCorridor,
  IMG.officeMeeting,
];

export const COMMERCIAL_SHOTS = [
  IMG.shopJewel,
  IMG.shopBeauty,
  IMG.shopFashion,
  IMG.shopBoutique,
  IMG.shopShelf,
  IMG.officeLobby,
];

export const NEIGHBOURHOOD_SHOTS: Record<string, string> = {
  vanak: IMG.livingChandelier,
  jordan: IMG.facadeGeo,
  mirdamad: IMG.livingMinimal,
  zafar: IMG.facadeTower,
  elahieh: IMG.villaTwilight,
  farmanieh: IMG.facadeModern,
  "saadat-abad": IMG.facadeGlass,
  "shahrak-gharb": IMG.livingPlan,
  "sheikh-bahaei": IMG.facadeWhite,
  marzdaran: IMG.facadeIzmir,
  poonak: IMG.livingOpen,
  dorous: IMG.facadePalm,
  kamkarha: IMG.kitchenLight,
  gholhak: IMG.livingBright,
};

/** Cinematic full-bleed backgrounds for the scroll-driven hero sequence. */
export const CINEMATIC_BACKGROUNDS = [
  { src: "/images/hero-villa.jpg", label: "ویلای کناک", caption: "معماریِ سفید، نورِ کهربایی" },
  { src: IMG.villaPool, label: "استخر بی‌نهایت", caption: "شبِ تهران از بالا" },
  { src: "/images/hero-penthouse.jpg", label: "پنت‌هاوس الهیه", caption: "غروبِ طلایی، نمای شهر" },
  { src: IMG.villaTwilight, label: "سعادت‌آباد", caption: "گرمایشِ نرم، سایهٔ عمیق" },
  { src: "/images/tehran-aerial.jpg", label: "شهرک غرب", caption: "افقِ البرز، خطوط نور" },
  { src: IMG.villaStone, label: "ظفر", caption: "سنگ، شیشه، سکوت" },
] as const;
