import { IMG } from "./images";

export type NeighborhoodSeed = {
  slug: string;
  name: string;
  nameEn: string;
  district: number;
  lat: number;
  lng: number;
  tagline: string;
  description: string;
  heroImage: string;
  salePerM2: number;
  depositPerM2: number;
  rentPerM2: number;
  yieldPct: number;
  trendPct: number;
  tags: string[];
  streets: string[];
  aliases: string[];
};

/** محله‌های منطقه ۲ و ۳ تهران — داده‌های قیمت پایه به تومان (معیار: آپارتمان ۲۰ ساله، مهر ۱۴۰۵). */
export const NEIGHBORHOODS: NeighborhoodSeed[] = [
  {
    slug: "elahieh",
    name: "الهیه",
    nameEn: "Elahieh",
    district: 3,
    lat: 35.7812,
    lng: 51.4253,
    tagline: "بلندترین خطِ آسمانِ تهران",
    description:
      "الهیه با شیب تند و نمای باز به شهر، گران‌قیمت‌ترین قطب مسکونی شمال تهران است؛ برج‌های کوتاه، ویلاهای بازسازی‌شده و کوچه‌های ساکت با پوشش درختان چنار.",
    heroImage: IMG.villaTwilight,
    salePerM2: 540_000_000,
    depositPerM2: 43_200_000,
    rentPerM2: 12_960_000,
    yieldPct: 2.6,
    trendPct: 34,
    tags: ["لوکس", "نمای شهر", "برج کم‌ارتفاع", "سفارشان"],
    streets: ["خیابان الهیه", "دربندی", "باغ فیض", "ماکو"],
    aliases: ["الهیه", "elahieh", "دربندی", "باغ فیض"],
  },
  {
    slug: "zafar",
    name: "ظفر و ظفرانیه",
    nameEn: "Zafar / Zaferaniyeh",
    district: 3,
    lat: 35.7762,
    lng: 51.4361,
    tagline: "کلاسِ آرامِ دیپلماتیک",
    description:
      "ظفرانیه با سفارت‌خانه‌ها و باغ‌های قدیمی، ترکیبی از عمارت‌های سفارتی و آپارتمان‌های نوسازِ مدیریت‌شده است؛ عرض خیابان‌ها زیاد و ترافیک آرام.",
    heroImage: IMG.facadeTower,
    salePerM2: 400_000_000,
    depositPerM2: 32_000_000,
    rentPerM2: 9_600_000,
    yieldPct: 2.6,
    trendPct: 30,
    tags: ["سفارشان", "نوساز", "آرام", "ویلا"],
    streets: ["خیابان ظفر", "محمود قندچی", "بنگلادش", "چایچی"],
    aliases: ["ظفر", "ظفرانیه", "زفر", "zafar", "zaferaniyeh"],
  },
  {
    slug: "farmanieh",
    name: "فرمانیه",
    nameEn: "Farmanieh",
    district: 3,
    lat: 35.7863,
    lng: 51.4472,
    tagline: "قطب خانواده‌های تازه‌ثروتمند",
    description:
      "فرمانیه با برج‌های نوساز و لابی‌های شیشه‌ای، محبوب‌ترین گزینهٔ خرید واحدهای بزرگ ۱۵۰ تا ۳۰۰ متری در شمال شرق تهران است.",
    heroImage: IMG.facadeModern,
    salePerM2: 520_000_000,
    depositPerM2: 41_600_000,
    rentPerM2: 12_480_000,
    yieldPct: 2.6,
    trendPct: 32,
    tags: ["نوساز", "لابی منشن", "پارکینگ دوگانه"],
    streets: ["فرمانیه", "لواسانی", "دستگردی", "علافچی"],
    aliases: ["فرمانیه", "farmanieh", "لواسانی"],
  },
  {
    slug: "jordan",
    name: "جردن (نلسون ماندلا)",
    nameEn: "Jordan / Nelson Mandela",
    district: 3,
    lat: 35.7701,
    lng: 51.4228,
    tagline: "شاهراهِ لوکسِ شمال تهران",
    description:
      "جردن یا بلوار نلسون ماندلا، ستون فقرات منطقه ۳ است؛ از میدان کتاب تا سیدخندان، پر از برج‌های اداری، کلینیک‌ها و آپارتمان‌های بازسازی‌شده.",
    heroImage: IMG.facadeGeo,
    salePerM2: 390_000_000,
    depositPerM2: 31_200_000,
    rentPerM2: 9_360_000,
    yieldPct: 2.7,
    trendPct: 29,
    tags: ["اداری", "بازسازی", "نزدیک مترو"],
    streets: ["بلوار نلسون ماندلا", "خیابان مریم", "وحیدی‌نیا", "عبدان", "کیانمیر"],
    aliases: ["جردن", "jordan", "نلسون ماندلا", "mandela", "آفریقا", "خیابان آفریقا"],
  },
  {
    slug: "mirdamad",
    name: "میرداماد",
    nameEn: "Mirdamad",
    district: 3,
    lat: 35.762,
    lng: 51.4302,
    tagline: "شهرِ دوتایی: اداری و مسکونی",
    description:
      "میرداماد از میدان هروی تا میدان مادر ادامه دارد و بهترین توازن بین قیمت، دسترسی مترو و کیفیت ساختمان را در منطقه ۳ ارائه می‌دهد.",
    heroImage: IMG.livingMinimal,
    salePerM2: 380_000_000,
    depositPerM2: 30_400_000,
    rentPerM2: 9_120_000,
    yieldPct: 2.7,
    trendPct: 27,
    tags: ["مترو", "اداری", "تجاری", "دسترسی عالی"],
    streets: ["بلوار میرداماد", "شاه نظری", "مظفر", "بقایی", "هروی"],
    aliases: ["میرداماد", "mirdamad", "شاه نظری", "هروی", "مادر"],
  },
  {
    slug: "gholhak",
    name: "قلهک و گلها",
    nameEn: "Gholhak / Gholha",
    district: 3,
    lat: 35.7566,
    lng: 51.4271,
    tagline: "قدیمی، درختی، دوست‌داشتنی",
    description:
      "قلهک با کوچه‌های باریک و درخت‌های کهنسال، انتخاب کسانی است که به دنبال واحد بزرگِ بازسازی‌شده با قیمت منطقی‌تر از جردن هستند.",
    heroImage: IMG.livingBright,
    salePerM2: 370_000_000,
    depositPerM2: 29_600_000,
    rentPerM2: 8_880_000,
    yieldPct: 2.8,
    trendPct: 25,
    tags: ["بازسازی", "درخت‌کهنسال", "واحد بزرگ"],
    streets: ["قلهک", "گلها", "شهرداری", "محمود"],
    aliases: ["قلهک", "گلها", "gholhak", "گلها"],
  },
  {
    slug: "vanak",
    name: "ونک",
    nameEn: "Vanak",
    district: 3,
    lat: 35.7566,
    lng: 51.4102,
    tagline: "قلبِ تجاریِ شمال",
    description:
      "ونک با تقاطع بزرگراه حقانی و ولیعصر، قطب دفاتر شرکت‌ها و آپارتمان‌های اداری-مسکونی است؛ دسترسی بی‌رقیب به کل تهران.",
    heroImage: IMG.livingChandelier,
    salePerM2: 400_000_000,
    depositPerM2: 32_000_000,
    rentPerM2: 9_600_000,
    yieldPct: 2.7,
    trendPct: 26,
    tags: ["تجاری", "دفتر کار", "دسترسی عالی"],
    streets: ["میدان ونک", "خیابان ونک", "گاندی", "بزرگراه حقانی", "بهشتی"],
    aliases: ["ونک", "vanak", "گاندی", "حقانی", "بهشتی"],
  },
  {
    slug: "shahrak-gharb",
    name: "شهرک غرب",
    nameEn: "Shahrak-e Gharb",
    district: 2,
    lat: 35.7662,
    lng: 51.3662,
    tagline: "شهری مدرن درون شهر",
    description:
      "شهرک غرب با بافتِ مهندسی‌شده، بلوارهای عریض و برج‌های نوساز، بهترین کیفیت ساخت منطقه ۲ را دارد؛ پایتخت برج‌های ۲۰ طبقه.",
    heroImage: IMG.livingPlan,
    salePerM2: 415_000_000,
    depositPerM2: 33_200_000,
    rentPerM2: 9_960_000,
    yieldPct: 2.6,
    trendPct: 28,
    tags: ["نوساز", "برج مرتفع", "پارکینگ", "لابی"],
    streets: ["بلوار دادمان", "سرو", "فردوس غربی", "مهستان", "فرحزادی"],
    aliases: ["شهرک غرب", "شهرک", "دادمان", "سرو", "shahrak", "فردوس غربی"],
  },
  {
    slug: "dorous",
    name: "دروس",
    nameEn: "Dorous",
    district: 3,
    lat: 35.7731,
    lng: 51.3563,
    tagline: "حاشیهٔ آرامِ شهرک",
    description:
      "دروس در شمال‌غرب شهرک غرب، با ساختمان‌های کم‌تراکم و خیابان‌های خلوت، انتخاب خانواده‌هایی است که سکوت را می‌خواهند.",
    heroImage: IMG.facadePalm,
    salePerM2: 430_000_000,
    depositPerM2: 34_400_000,
    rentPerM2: 10_320_000,
    yieldPct: 2.6,
    trendPct: 30,
    tags: ["کم‌تراکم", "آرام", "خانوادگی"],
    streets: ["دروس", "بلوار دریا", "اقدمیان", "شهیدی"],
    aliases: ["دروس", "dorous", "اقدمیان"],
  },
  {
    slug: "saadat-abad",
    name: "سعادت‌آباد",
    nameEn: "Saadat Abad",
    district: 2,
    lat: 35.7761,
    lng: 51.3761,
    tagline: "پهن، سبز، پرتنوع",
    description:
      "سعادت‌آباد از بلوار دریا تا کاج امتداد دارد؛ ترکیب برج‌های مسکونی، مراکز تجاری و رستوران‌ها، پرتقاضاترین محلهٔ منطقه ۲ است.",
    heroImage: IMG.facadeGlass,
    salePerM2: 470_000_000,
    depositPerM2: 37_600_000,
    rentPerM2: 11_280_000,
    yieldPct: 2.6,
    trendPct: 27,
    tags: ["پرتقاضا", "تجاری", "رستوران", "دریا"],
    streets: ["بلوار دریا", "علامه شمالی", "سرو غربی", "کاج", "سی‌متری سعادت‌آباد"],
    aliases: ["سعادت آباد", "سعادت‌آباد", "saadat", "بلوار دریا", "کاج", "علامه"],
  },
  {
    slug: "kamkarha",
    name: "کامکارها",
    nameEn: "Kamkarha",
    district: 2,
    lat: 35.7722,
    lng: 51.3782,
    tagline: "محلهٔ رو‌به‌رشدِ جردنِ غرب",
    description:
      "خیابان کامکارها و اطراف آن، با ساختمان‌های ۵ تا ۱۰ ساله و قیمتِ پایین‌تر از سعادت‌آباد، بهترین نسبت کیفیت به قیمت را در منطقه ۲ دارد.",
    heroImage: IMG.kitchenLight,
    salePerM2: 430_000_000,
    depositPerM2: 34_400_000,
    rentPerM2: 10_320_000,
    yieldPct: 2.6,
    trendPct: 31,
    tags: ["به‌صرفه", "روبه‌رشد", "خانوادگی"],
    streets: ["خیابان کامکارها", "بولدان", "احمدیان", "کمالی"],
    aliases: ["کامکارها", "کامکار", "kamkarha", "بولدان", "احمدیان"],
  },
  {
    slug: "marzdaran",
    name: "مرزداران",
    nameEn: "Marzdaran",
    district: 2,
    lat: 35.7561,
    lng: 51.3622,
    tagline: "محور اداریِ غرب",
    description:
      "بلوار مرزداران، محل استقرار شرکت‌ها، کلینیک‌ها و واحدهای اداری است؛ قیمت اجارهٔ اداری به‌مراتب مناسب‌تر از میرداماد.",
    heroImage: IMG.facadeIzmir,
    salePerM2: 272_000_000,
    depositPerM2: 21_760_000,
    rentPerM2: 6_528_000,
    yieldPct: 2.9,
    trendPct: 22,
    tags: ["اداری", "کلینیک", "دفتر کار", "به‌صرفه"],
    streets: ["بلوار مرزداران", "سلطانی", "ایران‌زمین", "شهید پژمان"],
    aliases: ["مرزداران", "marzdaran", "ایران زمین", "ایران‌زمین"],
  },
  {
    slug: "sheikh-bahaei",
    name: "شیخ بهایی",
    nameEn: "Sheikh Bahaei",
    district: 2,
    lat: 35.7462,
    lng: 51.3862,
    tagline: "پرتقاضاترین محلهٔ دانشجویی",
    description:
      "شیخ بهایی با نزدیکی به دانشگاه‌ها و مترو، نقدشونده‌ترین محله برای واحدهای کوچک اجاره‌ای و سرمایه‌گذاری با بازده بالا است.",
    heroImage: IMG.facadeWhite,
    salePerM2: 330_000_000,
    depositPerM2: 26_400_000,
    rentPerM2: 7_920_000,
    yieldPct: 2.8,
    trendPct: 21,
    tags: ["بازده بالا", "اجارهٔ سریع", "دانشجویی", "نزدیک مترو"],
    streets: ["بلوار شیخ بهایی", "بلوار فردوس", "خیابان کاج", "چهارصددستگاه"],
    aliases: ["شیخ بهایی", "sheikh bahaei", "فردوس", "چهارصد دستگاه"],
  },
  {
    slug: "poonak",
    name: "پونک",
    nameEn: "Poonak",
    district: 2,
    lat: 35.7602,
    lng: 51.3522,
    tagline: "ورودیِ اقتصادیِ شمال‌غرب",
    description:
      "پونک با قیمتِ ورود پایین‌تر و دسترسی به بزرگراه‌ها، گزینهٔ محبوب خرید اولین خانه و واحدهای ۷۰ تا ۱۰۰ متری است.",
    heroImage: IMG.livingOpen,
    salePerM2: 300_000_000,
    depositPerM2: 24_000_000,
    rentPerM2: 7_200_000,
    yieldPct: 2.9,
    trendPct: 20,
    tags: ["خانهٔ اول", "اقتصادی", "دسترسی بزرگراه"],
    streets: ["بلوار پونک", "آفتاب", "دستگردی", "ملاصدرا"],
    aliases: ["پونک", "poonak", "آفتاب"],
  },
];

export const PROPERTY_TYPE_LABEL: Record<string, string> = {
  apartment: "آپارتمان",
  villa: "ویلایی",
  mixed: "مستغلات",
  old: "کلنگی",
  shop: "مغازه",
};

export const CATEGORY_LABEL: Record<string, string> = {
  residential: "مسکونی",
  office: "اداری",
  commercial: "تجاری",
};

export const DEAL_LABEL: Record<string, string> = {
  sale: "فروش",
  rent: "رهن و اجاره",
};

const FEATURE_POOL = [
  "لابی منشن",
  "استخر و سونا",
  "درب پارکینگ ریموت",
  "نگهبانی ۲۴ ساعته",
  "آسانسور اتاق‌دار",
  "سیستم هوشمند ساختمان",
  "پکیج و رادیاتور",
  "پنجره دوجداره UPVC",
  "نمای سنگ تراورتن",
  "کابینت های‌گلاس",
  "کف سرامیک گرانیتی",
  "سالن ورزش",
  "تراس خاک‌ریز",
  "انباری",
  "سند تک‌برگ",
  "چیلر و فن‌کویل",
  "دوبلکس",
  "حیاط اختصاصی",
];

const DESC_TEMPLATES = [
  "واحد کاملاً بازسازی‌شده با نورگیری عالی و نقشهٔ هوشمند؛ آشپزخانهٔ اپن با کابینت های‌گلاس و صفحهٔ کورین. طبقهٔ بالا با نمای باز به شهر.",
  "ساختمان مدیریت‌شده با لابی منشن و نگهبانی شبانه‌روزی؛ واحدها تحویل فوری و آمادهٔ سکونت. دسترسی پیاده به مترو و خطوط اصلی اتوبوس.",
  "نوساز با اسکلت فلزی و نمای سنگ تراورتن؛ سیم‌کشی کامل، کف سرامیک درجه‌یک و پنجره‌های دوجداره. مناسب سکونت یا دفتر کار.",
  "واحد بزرگ و خوش‌نقشه با پلانِ بدون پیلوت، دو پارکینگ و انباری. سند تک‌برگ و آمادهٔ انتقال.",
  "فرصت سرمایه‌گذاری؛ بافت قدیمی و قابلیت ساخت مجاز با تراکم بالا. موقعیت عالی برای سازنده و مشارکت در ساخت.",
];

const AGE_CURVE: Array<[number, number]> = [
  [0, 1.56], [2, 1.48], [5, 1.38], [8, 1.28], [10, 1.22], [13, 1.15],
  [15, 1.1], [18, 1.04], [20, 1.0], [25, 0.92], [30, 0.85], [40, 0.76], [60, 0.68],
];

function ageMultiplier(age: number): number {
  if (age <= 0) return AGE_CURVE[0][1];
  for (let i = 1; i < AGE_CURVE.length; i += 1) {
    const [x1, y1] = AGE_CURVE[i];
    const [x0, y0] = AGE_CURVE[i - 1];
    if (age <= x1) return y0 + ((y1 - y0) * (age - x0)) / (x1 - x0);
  }
  return AGE_CURVE[AGE_CURVE.length - 1][1];
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const round = (n: number, step: number) => Math.max(step, Math.round(n / step) * step);

const TYPE_MULTIPLIER: Record<string, number> = {
  apartment: 1,
  villa: 1.34,
  mixed: 1.12,
  old: 0.82,
  shop: 1.62,
  office: 0.94,
};

const IMAGE_POOLS: Record<string, string[]> = {
  apartment: [IMG.facadePalm, IMG.facadeGeo, IMG.facadeBalcony, IMG.facadeTower, IMG.facadeModern, IMG.facadeWhite, IMG.facadeIzmir, IMG.facadeGlass],
  villa: [IMG.villaDusk, IMG.villaPool, IMG.villaTwilight, IMG.villaStone, IMG.villaInfinity, IMG.villaSunset, IMG.villaGarden, IMG.villaNight],
  mixed: [IMG.livingChandelier, IMG.livingPlan, IMG.facadeClassic, IMG.officeLobby, IMG.shopJewel],
  old: [IMG.facadeClassic, IMG.facadeWorm, IMG.villaGarden, IMG.livingRug],
  shop: [IMG.shopJewel, IMG.shopBeauty, IMG.shopFashion, IMG.shopBoutique, IMG.shopShelf, IMG.shopMakeup, IMG.shopJewel2],
  office: [IMG.officeGlass, IMG.officeLobby, IMG.officeBright, IMG.officeOpen, IMG.officeBoard, IMG.officeMeeting, IMG.officeCorridor, IMG.officeStools],
};

const INTERIORS = [
  IMG.livingChandelier,
  IMG.livingMinimal,
  IMG.livingOpen,
  IMG.kitchenMarble,
  IMG.kitchenLight,
  IMG.livingSoft,
  IMG.livingBright,
  IMG.livingLoft,
  IMG.kitchenTiles,
  IMG.livingPlan,
];

export type PropertySeed = {
  code: string;
  slug: string;
  title: string;
  dealType: string;
  category: string;
  propertyType: string;
  neighborhoodSlug: string;
  address: string;
  areaM2: number;
  rooms: number;
  bedrooms: number;
  bathrooms: number;
  floor: number;
  totalFloors: number;
  buildYear: number;
  price: number | null;
  deposit: number | null;
  rentMonthly: number | null;
  pricePerM2: number | null;
  hasParking: boolean;
  hasElevator: boolean;
  hasBalcony: boolean;
  hasYard: boolean;
  isRenovated: boolean;
  features: string[];
  description: string;
  images: string[];
  isFeatured: boolean;
  views: number;
};

const faNum = (n: number) => n.toLocaleString("fa-IR", { useGrouping: false });

/** تولید قطعی (deterministic) فهرست آگهی‌ها */
export function buildProperties(): PropertySeed[] {
  const rand = mulberry32(20260215);
  const out: PropertySeed[] = [];
  let counter = 1000;

  const plans: Array<{
    type: string;
    category: string;
    areas: number[];
  }> = [
    { type: "apartment", category: "residential", areas: [75, 88, 100, 105, 120, 135, 150, 180, 210, 260] },
    { type: "apartment", category: "residential", areas: [65, 80, 95, 110, 145, 200] },
    { type: "villa", category: "residential", areas: [320, 420, 500, 680, 850] },
    { type: "old", category: "residential", areas: [90, 120, 160, 200, 250] },
    { type: "mixed", category: "commercial", areas: [110, 160, 220, 300] },
    { type: "shop", category: "commercial", areas: [22, 35, 48, 60, 85] },
    { type: "apartment", category: "office", areas: [70, 95, 130, 180, 240] },
  ];

  NEIGHBORHOODS.forEach((nb, nbIndex) => {
    plans.forEach((plan, planIndex) => {
      const listingsForPlan = plan.type === "apartment" ? 2 : 1;
      for (let k = 0; k < listingsForPlan; k += 1) {
        const area = plan.areas[Math.floor(rand() * plan.areas.length)];
        const dealType = rand() > 0.42 ? "sale" : "rent";
        const buildYear = 1370 + Math.floor(rand() * 54);
        const rooms = area < 80 ? 2 : area < 120 ? 2 + Math.round(rand()) : area < 200 ? 3 + Math.round(rand()) : 4 + Math.round(rand() * 2);
        const totalFloors = plan.type === "villa" ? 2 : 4 + Math.floor(rand() * 12);
        const floor = plan.type === "villa" ? 0 : Math.floor(rand() * totalFloors);
        const street = nb.streets[Math.floor(rand() * nb.streets.length)];

        const basePerM = nb.salePerM2 * (TYPE_MULTIPLIER[plan.type] ?? 1);
        // سن ساختمان و طبقه اثر معکوس روی قیمت هر متر دارد
        const ageFactor = ageMultiplier(1405 - buildYear);
        const floorFactor = plan.type === "villa" ? 1.05 : 1 + (floor / Math.max(1, totalFloors)) * 0.06;
        const areaFactor = area > 200 ? 0.94 : area < 90 ? 1.05 : 1;
        const jitter = 0.94 + rand() * 0.14;
        const perM = Math.round((basePerM * ageFactor * floorFactor * areaFactor * jitter) / 1_000_000) * 1_000_000;

        const price = dealType === "sale" ? round(perM * area, 100_000_000) : null;
        const fullDeposit = round(nb.depositPerM2 * (TYPE_MULTIPLIER[plan.type] ?? 1) * area, 50_000_000);
        const fullRent = round(nb.rentPerM2 * (TYPE_MULTIPLIER[plan.type] ?? 1) * area, 1_000_000);
        const ratio = fullDeposit / Math.max(1, fullRent);
        const deposit = dealType === "rent" ? round(fullDeposit * (0.2 + rand() * 0.55), 50_000_000) : null;
        const rentMonthly =
          dealType === "rent"
            ? round((fullDeposit - (deposit ?? 0)) / ratio + fullRent * 0.18, 1_000_000)
            : null;

        const pool = IMAGE_POOLS[plan.type] ?? IMAGE_POOLS.apartment;
        const start = Math.floor(rand() * pool.length);
        const images = [
          pool[start % pool.length],
          INTERIORS[(start + 3) % INTERIORS.length],
          INTERIORS[(start + 6) % INTERIORS.length],
          pool[(start + 2) % pool.length],
          INTERIORS[(start + 1) % INTERIORS.length],
        ];

        const featureCount = 3 + Math.floor(rand() * 4);
        const features = Array.from({ length: featureCount }, () => FEATURE_POOL[Math.floor(rand() * FEATURE_POOL.length)]).filter(
          (v, i, arr) => arr.indexOf(v) === i,
        );

        counter += 1;
        const typeLabel = PROPERTY_TYPE_LABEL[plan.type];
        const isOffice = plan.category === "office";
        const isShop = plan.type === "shop";
        const title =
          plan.type === "old"
            ? `کلنگی ${faNum(area)} متری • ${nb.name}`
            : `${typeLabel} ${faNum(area)} متری${isOffice ? " اداری" : isShop ? " تجاری" : ""} • ${nb.name}`;

        out.push({
          code: `DH-${counter}`,
          slug: `${plan.type}-${nb.slug}-${area}-${counter}`,
          title,
          dealType,
          category: plan.category,
          propertyType: plan.type,
          neighborhoodSlug: nb.slug,
          address: `${street}، ${nb.name}، منطقه ${faNum(nb.district)}`,
          areaM2: area,
          rooms,
          bedrooms: Math.max(1, rooms - 1),
          bathrooms: 1 + Math.floor(area / 90),
          floor,
          totalFloors,
          buildYear,
          price,
          deposit,
          rentMonthly,
          pricePerM2: dealType === "sale" ? Math.round((price ?? 0) / area) : null,
          hasParking: plan.type === "shop" ? rand() > 0.6 : rand() > 0.25,
          hasElevator: plan.type === "villa" || plan.type === "old" ? rand() > 0.8 : rand() > 0.12,
          hasBalcony: plan.type === "villa" || plan.type === "old" ? rand() > 0.5 : rand() > 0.25,
          hasYard: plan.type === "villa" || plan.type === "old" ? rand() > 0.25 : rand() > 0.9,
          isRenovated: buildYear < 1390 ? rand() > 0.35 : rand() > 0.7,
          features,
          description: DESC_TEMPLATES[(nbIndex + planIndex + k) % DESC_TEMPLATES.length],
          images,
          isFeatured: false,
          views: 40 + Math.floor(rand() * 900),
        });
      }
    });
  });

  // انتخاب آگهی‌های شاخص برای صفحهٔ اصلی
  const saleSorted = out.filter((p) => p.dealType === "sale").sort((a, b) => (b.pricePerM2 ?? 0) - (a.pricePerM2 ?? 0));
  saleSorted.slice(0, 6).forEach((p) => {
    p.isFeatured = true;
  });
  const rentSorted = out.filter((p) => p.dealType === "rent").sort((a, b) => (b.rentMonthly ?? 0) - (a.rentMonthly ?? 0));
  rentSorted.slice(0, 4).forEach((p) => {
    p.isFeatured = true;
  });

  return out;
}
