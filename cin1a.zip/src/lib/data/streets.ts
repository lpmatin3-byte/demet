/** ضریب اعتباری خیابان‌های شاخص منطقه ۲ و ۳ تهران (مهر ۱۴۰۵). */
export type StreetTier = { street: string; neighborhood: string; factor: number };

export const STREET_TIERS: StreetTier[] = [
  // منطقه ۳
  { street: "بلوار نلسون ماندلا", neighborhood: "jordan", factor: 1.14 },
  { street: "خیابان آفریقا", neighborhood: "jordan", factor: 1.14 },
  { street: "خیابان مریم", neighborhood: "jordan", factor: 1.06 },
  { street: "خیابان کیانمیر", neighborhood: "jordan", factor: 1.03 },
  { street: "خیابان وحیدی‌نیا", neighborhood: "jordan", factor: 1.0 },
  { street: "خیابان عبدان", neighborhood: "jordan", factor: 0.97 },
  { street: "خیابان دربندی", neighborhood: "elahieh", factor: 1.1 },
  { street: "خیابان باغ فیض", neighborhood: "elahieh", factor: 1.06 },
  { street: "خیابان ماکو", neighborhood: "elahieh", factor: 0.98 },
  { street: "خیابان الهیه", neighborhood: "elahieh", factor: 1.08 },
  { street: "خیابان ظفر", neighborhood: "zafar", factor: 1.09 },
  { street: "خیابان بنگلادش", neighborhood: "zafar", factor: 1.04 },
  { street: "خیابان محمود قندچی", neighborhood: "zafar", factor: 1.0 },
  { street: "خیابان لواسانی", neighborhood: "farmanieh", factor: 1.06 },
  { street: "خیابان دستگردی", neighborhood: "farmanieh", factor: 1.02 },
  { street: "خیابان علافچی", neighborhood: "farmanieh", factor: 1.0 },
  { street: "بلوار میرداماد", neighborhood: "mirdamad", factor: 1.05 },
  { street: "خیابان شاه نظری", neighborhood: "mirdamad", factor: 1.0 },
  { street: "خیابان هروی", neighborhood: "mirdamad", factor: 0.92 },
  { street: "خیابان مظفر", neighborhood: "mirdamad", factor: 0.96 },
  { street: "خیابان گاندی", neighborhood: "vanak", factor: 1.11 },
  { street: "خیابان ونک", neighborhood: "vanak", factor: 1.02 },
  { street: "خیابان بهشتی", neighborhood: "vanak", factor: 1.0 },
  { street: "بزرگراه حقانی", neighborhood: "vanak", factor: 1.04 },
  { street: "خیابان گلها", neighborhood: "gholhak", factor: 1.0 },
  { street: "خیابان شهرداری", neighborhood: "gholhak", factor: 0.95 },
  // منطقه ۲
  { street: "صرافهای شمالی", neighborhood: "saadat-abad", factor: 1.16 },
  { street: "خیابان صرافها", neighborhood: "saadat-abad", factor: 1.16 },
  { street: "میدان کاج", neighborhood: "saadat-abad", factor: 1.11 },
  { street: "بلوار دریا", neighborhood: "saadat-abad", factor: 1.08 },
  { street: "کوی فراز", neighborhood: "saadat-abad", factor: 1.07 },
  { street: "خیابان ۲۴ متری", neighborhood: "saadat-abad", factor: 1.06 },
  { street: "بلوار فرهنگ", neighborhood: "saadat-abad", factor: 1.05 },
  { street: "خیابان رستگاری", neighborhood: "saadat-abad", factor: 1.05 },
  { street: "خیابان مروارید", neighborhood: "saadat-abad", factor: 1.03 },
  { street: "علامه شمالی", neighborhood: "saadat-abad", factor: 1.02 },
  { street: "بلوار دادمان", neighborhood: "shahrak-gharb", factor: 1.08 },
  { street: "خیابان سرو", neighborhood: "shahrak-gharb", factor: 1.04 },
  { street: "خیابان مهستان", neighborhood: "shahrak-gharb", factor: 1.03 },
  { street: "خیابان پارس", neighborhood: "shahrak-gharb", factor: 1.03 },
  { street: "فردوس غربی", neighborhood: "shahrak-gharb", factor: 0.97 },
  { street: "بلوار فرحزادی", neighborhood: "shahrak-gharb", factor: 1.0 },
  { street: "خیابان کامکارها", neighborhood: "kamkarha", factor: 1.02 },
  { street: "خیابان بولدان", neighborhood: "kamkarha", factor: 0.98 },
  { street: "بلوار مرزداران", neighborhood: "marzdaran", factor: 1.02 },
  { street: "بلوار ایران زمین", neighborhood: "marzdaran", factor: 0.98 },
  { street: "بلوار شیخ بهایی", neighborhood: "sheikh-bahaei", factor: 1.02 },
  { street: "بلوار فردوس", neighborhood: "sheikh-bahaei", factor: 0.96 },
  { street: "بلوار دریا دروس", neighborhood: "dorous", factor: 1.06 },
  { street: "خیابان اقدمیان", neighborhood: "dorous", factor: 1.0 },
  { street: "بلوار پونک", neighborhood: "poonak", factor: 1.0 },
  { street: "خیابان آفتاب", neighborhood: "poonak", factor: 0.97 },
];

const norm = (v: string) =>
  v
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/خیابون|خیابن/g, "خیابان")
    .replace(/بلورون/g, "بلوار")
    .replace(/\u200c/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

export function findStreetTier(text: string): StreetTier | null {
  const t = norm(text);
  if (!t) return null;
  let best: StreetTier | null = null;
  let bestLen = 0;
  for (const tier of STREET_TIERS) {
    const key = norm(tier.street);
    if (t.includes(key) && key.length > bestLen) {
      best = tier;
      bestLen = key.length;
    }
  }
  return best;
}
