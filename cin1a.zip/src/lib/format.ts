const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function toFa(input: number | string): string {
  return String(input).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

export function withGrouping(n: number): string {
  return toFa(Math.round(n).toLocaleString("en-US"));
}

/** ۱۲٫۵ میلیارد تومان / ۴۵۰ میلیون تومان */
export function formatPriceShort(n: number | null | undefined): string {
  if (n === null || n === undefined || Number.isNaN(n)) return "توافقی";
  if (n >= 1_000_000_000) {
    const v = n / 1_000_000_000;
    const s = v >= 10 ? v.toFixed(1) : v.toFixed(2);
    return `${toFa(s.replace(/\.?0+$/, ""))} میلیارد تومان`;
  }
  if (n >= 1_000_000) return `${withGrouping(n / 1_000_000)} میلیون تومان`;
  return `${withGrouping(n)} تومان`;
}

export function formatPerM2(n: number | null | undefined): string {
  if (!n) return "—";
  return `${withGrouping(n / 1_000_000)} میلیون / متر`;
}

/** ۱.۷۵ میلیون تومان / ۸۵۰ هزار تومان */
export function formatShortToman(n: number): string {
  if (Math.abs(n) >= 1_000_000) {
    const v = n / 1_000_000;
    const txt = v >= 10 ? v.toFixed(1) : v.toFixed(2);
    return `${toFa(txt.replace(/\.?0+$/, ""))} میلیون تومان`;
  }
  if (Math.abs(n) >= 1_000) return `${withGrouping(n / 1000)} هزار تومان`;
  return `${withGrouping(n)} تومان`;
}

export function formatArea(n: number): string {
  return `${toFa(n)} متر`;
}

export function formatRentLine(deposit: number | null, rent: number | null): string {
  if (deposit === null || deposit === undefined) return "توافقی";
  if (!rent) return `رهن کامل ${formatPriceShort(deposit)}`;
  return `رهن ${formatPriceShort(deposit)} • اجاره ${formatPriceShort(rent)}`;
}

export function jalaliYear(year: number): string {
  return toFa(year);
}

export const DEAL_TABS = [
  { value: "sale", label: "فروش" },
  { value: "rent", label: "رهن و اجاره" },
] as const;

export const CATEGORY_TABS = [
  { value: "residential", label: "مسکونی" },
  { value: "office", label: "اداری" },
  { value: "commercial", label: "تجاری" },
] as const;

export const TYPE_TABS = [
  { value: "apartment", label: "آپارتمان" },
  { value: "villa", label: "ویلایی" },
  { value: "mixed", label: "مستغلات" },
  { value: "old", label: "کلنگی" },
  { value: "shop", label: "مغازه" },
] as const;
