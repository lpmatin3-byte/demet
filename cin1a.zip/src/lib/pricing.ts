import { NEIGHBORHOODS } from "@/lib/data/seed-data";
import { findStreetTier } from "@/lib/data/streets";

/**
 * موتور قیمت‌گذاری هدونیک (Hedonic) Demet Home
 * قیمت هر متر = پایهٔ محله × ضریب خیابان × ضریب نوع ملک × ضریب سن بنا × ضریب طبقه × ضریب متراژ × ضریب وضعیت
 * پایهٔ محله = آپارتمان ۲۰ سالهٔ استاندارد در خیابان میانی آن محله (مهر ۱۴۰۵)
 */

export const CURRENT_YEAR = 1405;

/** نسبت ودیعهٔ کامل به ارزش ملک */
export const FULL_DEPOSIT_RATIO = 0.08;
/** ضریب تبدیل ودیعه به اجارهٔ ماهانه (اجاره = ودیعه × ضریب) */
export const RENT_PER_DEPOSIT = 0.03;

const AGE_CURVE: Array<[number, number]> = [
  [0, 1.56],
  [2, 1.48],
  [5, 1.38],
  [8, 1.28],
  [10, 1.22],
  [13, 1.15],
  [15, 1.1],
  [18, 1.04],
  [20, 1.0],
  [25, 0.92],
  [30, 0.85],
  [35, 0.8],
  [40, 0.76],
  [50, 0.71],
  [60, 0.68],
];

export const TYPE_FACTOR: Record<string, number> = {
  apartment: 1,
  villa: 1.32,
  mixed: 1.1,
  old: 0.72,
  shop: 1.58,
  office: 0.92,
};

export const TYPE_LABEL: Record<string, string> = {
  apartment: "آپارتمان",
  villa: "ویلایی",
  mixed: "مستغلات",
  old: "کلنگی",
  shop: "مغازه",
  office: "واحد اداری",
};

export const ORIENTATION_FACTOR: Record<string, number> = {
  north: 1.07,
  south: 0.93,
  east: 1.0,
  west: 0.98,
  unknown: 1.0,
};

function interpolateAge(age: number): number {
  if (age <= AGE_CURVE[0][0]) return AGE_CURVE[0][1];
  for (let i = 1; i < AGE_CURVE.length; i += 1) {
    const [x1, y1] = AGE_CURVE[i];
    const [x0, y0] = AGE_CURVE[i - 1];
    if (age <= x1) {
      const t = (age - x0) / Math.max(0.001, x1 - x0);
      return y0 + (y1 - y0) * t;
    }
  }
  return AGE_CURVE[AGE_CURVE.length - 1][1];
}

function areaFactor(area: number): number {
  if (area <= 70) return 1.05;
  if (area <= 95) return 1.02;
  if (area <= 160) return 1.0;
  if (area <= 250) return 0.95;
  if (area <= 400) return 0.9;
  return 0.86;
}

export type UnitInput = {
  neighborhoodSlug: string;
  street?: string | null;
  propertyType: string;
  areaM2: number;
  buildYear?: number | null;
  ageYears?: number | null;
  floor?: number | null;
  totalFloors?: number | null;
  renovated?: boolean;
  orientation?: keyof typeof ORIENTATION_FACTOR;
};

export type FactorRow = { label: string; value: string; note: string };

export type Valuation = {
  neighborhood: string;
  typeLabel: string;
  areaM2: number;
  buildYear: number;
  ageYears: number;
  streetLabel: string;
  perM2: number;
  total: number;
  low: number;
  high: number;
  factors: FactorRow[];
  rent: {
    fullDeposit: number;
    fullRent: number;
    ratio: number;
    scenarios: Array<{ label: string; deposit: number; rent: number }>;
  };
};

const round = (n: number, step: number) => Math.max(step, Math.round(n / step) * step);

export function valueUnit(input: UnitInput): Valuation | null {
  const nb = NEIGHBORHOODS.find((n) => n.slug === input.neighborhoodSlug);
  if (!nb) return null;

  const area = Math.max(15, input.areaM2);
  const ageYears =
    input.ageYears ??
    (input.buildYear ? Math.max(0, Math.min(70, CURRENT_YEAR - input.buildYear)) : 20);
  const buildYear = input.buildYear ?? CURRENT_YEAR - ageYears;

  const tier = input.street ? findStreetTier(input.street) : null;
  const streetFactor = tier?.factor ?? 1;
  const type = input.propertyType in TYPE_FACTOR ? input.propertyType : "apartment";
  const typeFactor = TYPE_FACTOR[type];
  const ageF = interpolateAge(ageYears);
  const areaF = areaFactor(area);
  const orientationF = ORIENTATION_FACTOR[input.orientation ?? "unknown"];

  const totalFloors = input.totalFloors ?? Math.max(1, (input.floor ?? 3) + 1);
  const floor = input.floor ?? Math.max(0, Math.floor(totalFloors / 2));
  const floorF =
    type === "villa"
      ? 1.04
      : 1 + 0.055 * (floor / Math.max(1, totalFloors)) + (floor === totalFloors ? 0.05 : 0);

  const conditionF = input.renovated ? 1.06 : 1.0;

  const perM2 = Math.round((nb.salePerM2 * streetFactor * typeFactor * ageF * areaF * floorF * orientationF * conditionF) / 1_000_000) * 1_000_000;
  const total = round(perM2 * area, 250_000_000);
  const low = round(total * 0.9, 250_000_000);
  const high = round(total * 1.12, 250_000_000);

  const fullDeposit = round(total * FULL_DEPOSIT_RATIO, 50_000_000);
  const fullRent = round(fullDeposit * RENT_PER_DEPOSIT, 2_500_000);
  const ratio = fullDeposit / Math.max(1, fullRent);

  const scenarios = [
    { label: "رهن کامل (بدون اجاره)", deposit: fullDeposit, rent: 0 },
    {
      label: "متعادل — ۵۰٪ رهن کامل",
      deposit: round(fullDeposit * 0.5, 50_000_000),
      rent: round((fullDeposit - fullDeposit * 0.5) * RENT_PER_DEPOSIT, 2_500_000),
    },
    {
      label: "کم‌رهن — ۲۰٪ رهن کامل",
      deposit: round(fullDeposit * 0.2, 50_000_000),
      rent: round((fullDeposit - fullDeposit * 0.2) * RENT_PER_DEPOSIT, 2_500_000),
    },
  ];

  const pct = (v: number) => `${v.toFixed(2)}×`;

  const factors: FactorRow[] = [
    { label: "پایهٔ محله", value: `${Math.round(nb.salePerM2 / 1_000_000)} م.ت/متر`, note: `${nb.name}، آپارتمان ۲۰ ساله` },
    { label: "خیابان", value: pct(streetFactor), note: tier?.street ?? "خیابان میانی محله" },
    { label: "نوع ملک", value: pct(typeFactor), note: TYPE_LABEL[type] },
    { label: "سن بنا", value: pct(ageF), note: `${buildYear} — ${ageYears} ساله` },
    { label: "متراژ", value: pct(areaF), note: `${area} متر` },
    { label: "طبقه", value: pct(floorF), note: `طبقهٔ ${floor} از ${totalFloors}` },
  ];
  if (input.renovated) factors.push({ label: "بازسازی", value: pct(1.06), note: "بازسازی کامل" });
  if (orientationF !== 1) {
    factors.push({
      label: "جهت",
      value: pct(orientationF),
      note: input.orientation === "north" ? "شمالی" : input.orientation === "south" ? "جنوبی" : "غربی",
    });
  }

  return {
    neighborhood: nb.name,
    typeLabel: TYPE_LABEL[type],
    areaM2: area,
    buildYear,
    ageYears,
    streetLabel: tier?.street ?? "خیابان میانی محله",
    perM2,
    total,
    low,
    high,
    factors,
    rent: { fullDeposit, fullRent, ratio, scenarios },
  };
}
