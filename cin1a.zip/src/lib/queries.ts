import { and, asc, desc, eq, gte, ilike, lte, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeeded } from "@/db/seed";
import { buildings, neighborhoods, properties, type Building, type Neighborhood, type Property } from "@/db/schema";

export type PropertyFilters = {
  deal?: string;
  category?: string;
  type?: string;
  neighborhood?: string;
  minArea?: number;
  maxArea?: number;
  rooms?: number;
  minPrice?: number;
  maxPrice?: number;
  q?: string;
  sort?: string;
  limit?: number;
  featured?: boolean;
};

export async function getNeighborhoods(): Promise<Neighborhood[]> {
  await ensureSeeded();
  return db.select().from(neighborhoods).orderBy(desc(neighborhoods.salePerM2));
}

export async function getNeighborhood(slug: string): Promise<Neighborhood | null> {
  await ensureSeeded();
  const rows = await db.select().from(neighborhoods).where(eq(neighborhoods.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getProperties(filters: PropertyFilters = {}): Promise<Property[]> {
  await ensureSeeded();
  const where: SQL[] = [];
  if (filters.deal) where.push(eq(properties.dealType, filters.deal));
  if (filters.category) where.push(eq(properties.category, filters.category));
  if (filters.type) where.push(eq(properties.propertyType, filters.type));
  if (filters.neighborhood) where.push(eq(properties.neighborhoodSlug, filters.neighborhood));
  if (filters.featured) where.push(eq(properties.isFeatured, true));
  if (filters.minArea) where.push(gte(properties.areaM2, filters.minArea));
  if (filters.maxArea) where.push(lte(properties.areaM2, filters.maxArea));
  if (filters.rooms) where.push(gte(properties.rooms, filters.rooms));
  if (filters.minPrice) {
    const cond = or(gte(properties.price, filters.minPrice), gte(properties.deposit, filters.minPrice));
    if (cond) where.push(cond);
  }
  if (filters.maxPrice) {
    const cond = or(lte(properties.price, filters.maxPrice), lte(properties.deposit, filters.maxPrice));
    if (cond) where.push(cond);
  }
  if (filters.q) {
    const like = `%${filters.q}%`;
    const cond = or(ilike(properties.title, like), ilike(properties.address, like), ilike(properties.description, like));
    if (cond) where.push(cond);
  }

  const orderBy =
    filters.sort === "area"
      ? desc(properties.areaM2)
      : filters.sort === "price_asc"
        ? asc(sql`coalesce(${properties.price}, ${properties.deposit})`)
        : filters.sort === "price_desc"
          ? desc(sql`coalesce(${properties.price}, ${properties.deposit})`)
          : filters.sort === "new"
            ? desc(properties.buildYear)
            : desc(properties.isFeatured);

  return db
    .select()
    .from(properties)
    .where(where.length ? and(...where) : undefined)
    .orderBy(orderBy, desc(properties.id))
    .limit(Math.min(filters.limit ?? 48, 96));
}

export async function getBuildings(neighborhood?: string): Promise<Building[]> {
  await ensureSeeded();
  const rows = neighborhood
    ? await db.select().from(buildings).where(eq(buildings.neighborhoodSlug, neighborhood)).orderBy(desc(buildings.isFeatured), desc(buildings.salePerM2))
    : await db.select().from(buildings).orderBy(desc(buildings.isFeatured), desc(buildings.salePerM2));
  return rows;
}

export async function getBuildingBySlug(slug: string): Promise<Building | null> {
  await ensureSeeded();
  const rows = await db.select().from(buildings).where(eq(buildings.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export async function getPropertyBySlug(slug: string): Promise<Property | null> {
  await ensureSeeded();
  const rows = await db.select().from(properties).where(eq(properties.slug, slug)).limit(1);
  return rows[0] ?? null;
}

export type NbStats = {
  count: number;
  avgPerM2: number | null;
  minPerM2: number | null;
  maxPerM2: number | null;
  avgRent: number | null;
  avgDeposit: number | null;
  rentCount: number;
};

export async function getNeighborhoodStats(slug: string): Promise<NbStats> {
  await ensureSeeded();
  const rows = await db
    .select({
      count: sql<number>`count(*)::int`,
      avgPerM2: sql<number>`avg(${properties.pricePerM2})`,
      minPerM2: sql<number>`min(${properties.pricePerM2})`,
      maxPerM2: sql<number>`max(${properties.pricePerM2})`,
      avgRent: sql<number>`avg(${properties.rentMonthly})`,
      avgDeposit: sql<number>`avg(${properties.deposit})`,
      rentCount: sql<number>`count(${properties.rentMonthly})::int`,
    })
    .from(properties)
    .where(eq(properties.neighborhoodSlug, slug));

  const r = rows[0];
  return {
    count: Number(r?.count ?? 0),
    avgPerM2: r?.avgPerM2 ? Math.round(Number(r.avgPerM2)) : null,
    minPerM2: r?.minPerM2 ? Math.round(Number(r.minPerM2)) : null,
    maxPerM2: r?.maxPerM2 ? Math.round(Number(r.maxPerM2)) : null,
    avgRent: r?.avgRent ? Math.round(Number(r.avgRent)) : null,
    avgDeposit: r?.avgDeposit ? Math.round(Number(r.avgDeposit)) : null,
    rentCount: Number(r?.rentCount ?? 0),
  };
}

export async function getMarketSnapshot() {
  await ensureSeeded();
  const rows = await db
    .select({
      total: sql<number>`count(*)::int`,
      sale: sql<number>`count(*) filter (where ${properties.dealType} = 'sale')::int`,
      rent: sql<number>`count(*) filter (where ${properties.dealType} = 'rent')::int`,
      avgPerM2: sql<number>`avg(${properties.pricePerM2})`,
    })
    .from(properties);
  const r = rows[0];
  const nbs = await getNeighborhoods();
  return {
    total: Number(r?.total ?? 0),
    sale: Number(r?.sale ?? 0),
    rent: Number(r?.rent ?? 0),
    avgPerM2: r?.avgPerM2 ? Math.round(Number(r.avgPerM2)) : 0,
    neighborhoods: nbs.length,
  };
}
